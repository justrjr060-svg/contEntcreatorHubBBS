import { Creator, CommunityPost, CreatorApplication, Coupon, User } from '../types';

export const SYSTEM_MEMBERSHIP_PLANS = [
  {
    id: 'plan_bronze',
    title: 'Bronze Tier',
    price: 15.00,
    description: 'Access to basic exclusive posts, photos, and high-quality updates.',
    features: ['Access to member-only feed', 'Behind-the-scenes images', 'Basic comment privileges', 'Bronze badge on profile'],
    interval: 'month' as const,
    tier: 1
  },
  {
    id: 'plan_silver',
    title: 'Silver Tier',
    price: 50.00,
    description: 'Unlock direct updates, premium long-form articles, and exclusive video galleries.',
    features: ['All Bronze Tier features', 'Exclusive video content', 'Early-access posts & guides', 'Direct messages with Creator', 'Silver badge on profile'],
    interval: 'month' as const,
    tier: 2
  },
  {
    id: 'plan_gold',
    title: 'Gold VIP Tier',
    price: 100.00,
    description: 'Ultimate pass with personal collaborations, 1-on-1 virtual sessions, and custom digital assets.',
    features: ['All Silver Tier features', 'Monthly 1-on-1 video call', 'Priority collaboration eligibility', 'Request custom content', 'Gold VIP VIP badge'],
    interval: 'month' as const,
    tier: 3
  }
];

export const MOCK_USERS: User[] = [
  {
    id: 'user_1',
    email: 'supporter@creatorhub.com',
    username: 'gold_supporter',
    name: 'Julian Vance',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
    bio: 'Avid supporter of indie creators, high-end digital art collector, and brand designer.',
    role: 'member',
    isVerified: true,
    is2FAEnabled: false,
    activeSubscriptions: {
      'creator_1': {
        planId: 'plan_silver_creator_1',
        tier: 2,
        startDate: '2026-06-11',
        expiryDate: '2026-07-11',
        status: 'active'
      }
    },
    favorites: ['creator_1', 'creator_3'],
    status: 'active'
  },
  {
    id: 'admin_1',
    email: 'admin@creatorhub.com',
    username: 'crown_admin',
    name: 'Seraphina Gold',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=200',
    bio: 'Creator Hub Platform Administrator.',
    role: 'admin',
    isVerified: true,
    is2FAEnabled: true,
    activeSubscriptions: {},
    favorites: [],
    status: 'active'
  },
  {
    id: 'creator_user_1',
    email: 'jeana@creatorhub.com',
    username: 'jeana',
    name: 'Jeana',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
    bio: 'High Fashion & Luxury Lifestyle Content Creator.',
    role: 'creator',
    isVerified: true,
    is2FAEnabled: true,
    activeSubscriptions: {},
    favorites: [],
    status: 'active'
  }
];

export const MOCK_CREATORS: Creator[] = [
  {
    id: 'creator_1',
    name: 'Jeana',
    username: 'jeana',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
    bannerUrl: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=1200',
    bio: 'Exploring haute couture, sustainable luxury travel, and the world’s most refined aesthetics. Access curated styling lookbooks, private travel itineraries, and direct design mentorship.',
    category: 'Fashion & Luxury Travel',
    subscriberCount: 1420,
    tags: ['Luxury', 'Fashion', 'Travel Guide', 'Aesthetics'],
    isApproved: true,
    viewsCount: 45000,
    revenue: 12450,
    rating: 4.9,
    socialLinks: {
      twitter: 'https://twitter.com/jeana',
      instagram: 'https://instagram.com/jeana',
      youtube: 'https://youtube.com/jeana'
    },
    plans: [
      {
        id: 'plan_bronze_creator_1',
        title: 'Couture Insider',
        price: 15.00,
        description: 'Get exclusive access to weekly behind-the-scenes lookbooks and private luxury styling notes.',
        features: ['Weekly high-fashion journals', 'Private photo galleries', 'Access to general Q&A', 'Exclusive Discord Channel Access'],
        interval: 'month',
        tier: 1
      },
      {
        id: 'plan_silver_creator_1',
        title: 'Elite Jetsetter',
        price: 50.00,
        description: 'Detailed travel guides, custom destination presets, and monthly exclusive high-definition video vlogs.',
        features: ['All Couture Insider rewards', 'Exclusive 4K travel vlogs', 'Downloadable Lightroom presets', 'Pre-released styling lookbooks', 'Interactive travel polls'],
        interval: 'month',
        tier: 2
      },
      {
        id: 'plan_gold_creator_1',
        title: 'Atelier Circle',
        price: 100.00,
        description: 'The ultimate luxury masterclass. Personal styling consultations and direct collaboration opportunities.',
        features: ['All Elite Jetsetter rewards', 'Quarterly 1-on-1 virtual style session', 'Personalized shopping curation lists', 'Priority collaboration access', 'Hand-signed Atelier luxury card'],
        interval: 'month',
        tier: 3
      }
    ],
    posts: [
      {
        id: 'post_1_1',
        creatorId: 'creator_1',
        title: 'Private Styling Lookbook: Milan Autumn Edit',
        description: 'My curated selections and premium designer combinations for this autumn in Milan.',
        type: 'image',
        mediaUrl: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&q=80&w=800',
        minTier: 1,
        likes: 124,
        date: '2026-07-10',
        comments: [
          {
            id: 'c1',
            userId: 'user_1',
            username: 'gold_supporter',
            avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
            content: 'These tailoring recommendations are so precise! Love the gold accents on the cashmere coat.',
            date: '2026-07-10'
          }
        ]
      },
      {
        id: 'post_1_2',
        creatorId: 'creator_1',
        title: 'Exclusive: Hidden Gems of the Amalfi Coast',
        description: 'A 20-minute journey mapping out untouched luxury locations, boutique hotels, and authentic coastal experiences with no tourist crowd.',
        type: 'video',
        mediaUrl: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&q=80&w=800',
        minTier: 2,
        duration: '18:42',
        likes: 95,
        date: '2026-07-08',
        comments: []
      },
      {
        id: 'post_1_3',
        creatorId: 'creator_1',
        title: 'My Journey and Philosophy of Mindful Travel',
        description: 'A deeply personal essay reflecting on slower, high-value experiences rather than rapid tourism. Discussing luxury as a form of cultural respect.',
        type: 'blog',
        mediaUrl: 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&q=80&w=800',
        body: 'Mindful travel is not simply about staying in 5-star resorts; it is about how we enter a space. It represents an exchange of respect and aesthetic preservation. In this blog post, I discuss my curated selection of properties globally that prioritize local heritage while offering sublime comfort...',
        minTier: 0, // Public content
        likes: 310,
        date: '2026-07-05',
        comments: []
      }
    ]
  },
  {
    id: 'creator_2',
    name: 'Rachel',
    username: 'rachel',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
    bannerUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1200',
    bio: 'Venture Capitalist and Executive Advisor. Providing institutional-grade investment breakdowns, leadership frameworks, and private venture deal flow reports for high-net-worth supporters.',
    category: 'Finance & Leadership',
    subscriberCount: 840,
    tags: ['Venture Capital', 'Business', 'Leadership', 'Investing'],
    isApproved: true,
    viewsCount: 32000,
    revenue: 28400,
    rating: 4.85,
    socialLinks: {
      twitter: 'https://twitter.com/rachel'
    },
    plans: [
      {
        id: 'plan_bronze_creator_2',
        title: 'Venture Briefing',
        price: 15.00,
        description: 'Bi-weekly newsletters dissecting macro trends, tech investments, and private equity analysis.',
        features: ['Macro market newsletters', 'Private Q&A submissions', 'Access to member-only finance discussions'],
        interval: 'month',
        tier: 1
      },
      {
        id: 'plan_silver_creator_2',
        title: 'Boardroom Pass',
        price: 50.00,
        description: 'Access deep-dive case studies, executive video masterclasses, and pre-packaged venture deals analysis.',
        features: ['All Venture Briefing rewards', 'Monthly Masterclass video series', 'Detailed investment templates', 'Venture deal pipeline reports', 'Direct email responses'],
        interval: 'month',
        tier: 2
      },
      {
        id: 'plan_gold_creator_2',
        title: 'The Roundtable VIP',
        price: 100.00,
        description: 'Personal strategic advice. Periodic virtual roundtable briefings, private community access, and custom portfolio reviews.',
        features: ['All Boardroom Pass rewards', 'Bi-monthly small group roundtable calls', 'Venture advisory channel access', 'Portfolio audit request', 'VIP network networking events'],
        interval: 'month',
        tier: 3
      }
    ],
    posts: [
      {
        id: 'post_2_1',
        creatorId: 'creator_2',
        title: 'Venture Capital Trends: AI Infras & Cloud Scale 2026',
        description: 'My premium thesis on where late-stage venture capital is allocating capital this year.',
        type: 'blog',
        mediaUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=800',
        body: 'The venture paradigm of 2026 has transitioned from simple agentic software layers directly to hardware sovereignty and specialized private-cloud configurations. This paper analyzes why early-stage margins have collapsed, and where enterprise value is concentrating...',
        minTier: 1,
        likes: 184,
        date: '2026-07-09',
        comments: []
      },
      {
        id: 'post_2_2',
        creatorId: 'creator_2',
        title: 'Executive Masterclass: Scale Mechanics & Governance',
        description: 'A 45-minute premium workshop detailing standard pitfalls for Series-A organizations scaling from 20 to 100 staff.',
        type: 'video',
        mediaUrl: 'https://images.unsplash.com/photo-1515187029135-18ee286d815b?auto=format&fit=crop&q=80&w=800',
        minTier: 2,
        duration: '45:10',
        likes: 112,
        date: '2026-07-02',
        comments: []
      }
    ]
  },
  {
    id: 'creator_3',
    name: 'Kate',
    username: 'kate',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=200',
    bannerUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&q=80&w=1200',
    bio: 'Ambient Cinematic Sound Designer & Vocalist. Producing modular synthesizers landscapes, spatial atmospheric audio templates, and vocal stems for audio creators.',
    category: 'Music & Audio Design',
    subscriberCount: 2150,
    tags: ['Sound Design', 'Ambient', 'Synth', 'Production Stems'],
    isApproved: true,
    viewsCount: 61000,
    revenue: 16800,
    rating: 4.95,
    socialLinks: {
      youtube: 'https://youtube.com/kate',
      instagram: 'https://instagram.com/kate'
    },
    plans: [
      {
        id: 'plan_bronze_creator_3',
        title: 'Echo Level',
        price: 15.00,
        description: 'Full high-fidelity streams of all ambient drops, desktop wallpapers, and early single release files.',
        features: ['Full hi-res streaming', 'Desktop/mobile wallpapers', 'Early preview of cinematic albums', 'Weekly production diaries'],
        interval: 'month',
        tier: 1
      },
      {
        id: 'plan_silver_creator_3',
        title: 'Resonance Studio',
        price: 50.00,
        description: 'Royalties-free atmospheric pads, synth patches, and high-fidelity wav vocal loops for your tracks.',
        features: ['All Echo Level rewards', '10 Royalty-free WAV loops/month', 'Modular synthesizer patch sheets', 'Behind-the-scenes recording tutorials', 'Unreleased acoustic stems'],
        interval: 'month',
        tier: 2
      },
      {
        id: 'plan_gold_creator_3',
        title: 'Master Harmonic Circle',
        price: 100.00,
        description: 'Collaborative mixing critiques, custom sound designs tailored for your game or film, and direct audio guidance.',
        features: ['All Resonance Studio rewards', 'Custom 10-second sound effect crafted for your project', 'Monthly live audio feedback stream', 'Full credits on next album release', 'Direct production mentoring'],
        interval: 'month',
        tier: 3
      }
    ],
    posts: [
      {
        id: 'post_3_1',
        creatorId: 'creator_3',
        title: 'Cinematic Soundscape - Midnight Rain (Extended Mix)',
        description: 'A 10-minute spatial ambient mix with synthesized raindrops and analogue modular loops.',
        type: 'video',
        mediaUrl: 'https://images.unsplash.com/photo-1428908728789-d2de25dbd4e2?auto=format&fit=crop&q=80&w=800',
        minTier: 1,
        duration: '10:00',
        likes: 240,
        date: '2026-07-11',
        comments: []
      },
      {
        id: 'post_3_2',
        creatorId: 'creator_3',
        title: 'Resonance Loop Pack Vol 4: Solitude Synth',
        description: '15 bespoke high-fidelity vocal stems and modular drone wav patterns. Fully licensed for member commercial tracks.',
        type: 'image',
        mediaUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&q=80&w=800',
        minTier: 2,
        likes: 180,
        date: '2026-07-04',
        comments: []
      }
    ]
  }
];

export const MOCK_COMMUNITY_POSTS: CommunityPost[] = [
  {
    id: 'post_c_1',
    userId: 'user_1',
    username: 'gold_supporter',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
    title: 'How are you implementing Creator Hub stems in your video workflows?',
    content: 'Just subscribed to Kate’s Resonance Studio! I am compiling some 4K drone cinematography of Iceland and the ambient modular tracks blend so beautifully. Are you guys using them for podcasts, gaming streams, or short films?',
    likes: 24,
    reportsCount: 0,
    isPinned: true,
    category: 'general',
    date: '2026-07-11',
    comments: [
      {
        id: 'cc1',
        userId: 'creator_user_1',
        username: 'jeana',
        avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
        content: 'That sounds breathtaking, Julian! I’m actually discussing a luxury cinematic project where we might layer Kate’s synthesizers over runway footage.',
        date: '2026-07-11'
      }
    ],
    likedBy: ['admin_1']
  },
  {
    id: 'post_c_2',
    userId: 'creator_user_1',
    username: 'jeana',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
    title: 'Looking for a Finance Advisor for a Luxury Retail Launch!',
    content: 'Hi Hub! I am preparing a luxury accessories line launching in Q4 and would love to collaborate with a financial strategist who understands physical couture manufacturing and supply chain economics. Drop your portfolios below!',
    likes: 18,
    reportsCount: 0,
    category: 'collab',
    date: '2026-07-09',
    comments: []
  }
];

export const MOCK_APPLICATIONS: CreatorApplication[] = [
  {
    id: 'app_1',
    userId: 'user_temp_1',
    name: 'Vincent de Noir',
    email: 'vincent@denoir.com',
    username: 'vincentdenoir',
    category: 'Brutalist Architecture & Photography',
    description: 'Documenting concrete monuments, modernism, and high-contrast urban landscapes globally. Seeking a premium channel to provide architecture presets and luxury prints catalogs.',
    portfolioUrl: 'https://instagram.com/vincentdenoir_mock',
    status: 'pending',
    date: '2026-07-11'
  },
  {
    id: 'app_2',
    userId: 'user_temp_2',
    name: 'Serena Patel',
    email: 'serena@patelyoga.com',
    username: 'serenapatel',
    category: 'Mindfulness & Somatic Healing',
    description: 'Clinical somatic practitioner offering premium guided yoga sessions, high-definition sound baths, and holistic health coaching materials.',
    portfolioUrl: 'https://patelyoga.mock',
    status: 'pending',
    date: '2026-07-10'
  }
];

export const MOCK_COUPONS: Coupon[] = [
  {
    id: 'coup_1',
    code: 'HUBGOLD10',
    discountType: 'percent',
    value: 10,
    isActive: true
  },
  {
    id: 'coup_2',
    code: 'LUXURYVIP',
    discountType: 'fixed',
    value: 5,
    isActive: true
  }
];
