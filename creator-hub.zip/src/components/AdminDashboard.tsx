import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Users,
  ShieldAlert,
  Ticket,
  Megaphone,
  TrendingUp,
  Award,
  Check,
  X,
  AlertTriangle,
  UserCheck,
  Ban,
  Plus,
  Trash2,
  Lock,
  DollarSign
} from 'lucide-react';
import { User, CreatorApplication, Coupon, CommunityPost, ContentItem } from '../types';

interface AdminDashboardProps {
  currentUser: User;
  applications: CreatorApplication[];
  onApproveApplication: (appId: string) => void;
  onRejectApplication: (appId: string) => void;
  users: User[];
  onToggleUserStatus: (userId: string) => void;
  onToggleUserRole: (userId: string, newRole: 'admin' | 'creator' | 'member') => void;
  coupons: Coupon[];
  onAddCoupon: (coupon: Coupon) => void;
  onDeleteCoupon: (couponId: string) => void;
  onBroadcastAnnouncement: (title: string, message: string) => void;
  communityPosts: CommunityPost[];
  onDeleteCommunityPost: (postId: string) => void;
  activePresences?: any[];
}

export default function AdminDashboard({
  currentUser,
  applications,
  onApproveApplication,
  onRejectApplication,
  users,
  onToggleUserStatus,
  onToggleUserRole,
  coupons,
  onAddCoupon,
  onDeleteCoupon,
  onBroadcastAnnouncement,
  communityPosts,
  onDeleteCommunityPost,
  activePresences = []
}: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<'stats' | 'apps' | 'users' | 'moderation' | 'marketing' | 'broadcast'>('stats');

  // Coupon Form State
  const [couponCode, setCouponCode] = useState('');
  const [couponType, setCouponType] = useState<'percent' | 'fixed'>('percent');
  const [couponValue, setCouponValue] = useState<number>(10);

  // Announcement Form State
  const [announceTitle, setAnnounceTitle] = useState('');
  const [announceBody, setAnnounceBody] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleAddCouponSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode.trim()) return;

    onAddCoupon({
      id: 'coup_' + Date.now(),
      code: couponCode.toUpperCase().replace(/\s+/g, ''),
      discountType: couponType,
      value: couponValue,
      isActive: true
    });

    setCouponCode('');
    setCouponValue(10);
  };

  const handleBroadcastSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!announceTitle.trim() || !announceBody.trim()) return;

    onBroadcastAnnouncement(announceTitle, announceBody);
    setAnnounceTitle('');
    setAnnounceBody('');
    setSuccessMsg('Announcement successfully broadcast to all active subscribers!');
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  // Math totals for stats
  const totalSubscribers = users.filter((u) => u.role === 'member').length;
  const activeCreators = users.filter((u) => u.role === 'creator').length;
  const pendingApps = applications.filter((a) => a.status === 'pending').length;

  return (
    <div id="admin-dashboard-container" className="space-y-6">
      {/* Title block */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-neutral-900 pb-5">
        <div>
          <h2 className="font-display text-2xl font-bold tracking-tight text-white">
            Crown Administration <span className="gold-gradient-text">Dashboard</span>
          </h2>
          <p className="text-neutral-400 text-xs mt-1">
            System administration deck. Monitor platforms metrics, applications, moderation lists, and marketing campaigns.
          </p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-gold-500/10 border border-gold-400/20 text-gold-400 text-[11px] font-mono self-start md:self-auto">
          <Award size={14} />
          <span>Role: High Administrator</span>
        </div>
      </div>

      {/* Admin Menu Grid */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-2">
        {(['stats', 'apps', 'users', 'moderation', 'marketing', 'broadcast'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`py-2 px-3 rounded-xl font-display font-medium text-xs border transition ${
              activeTab === tab
                ? 'bg-gradient-to-r from-gold-600 to-gold-400 text-neutral-950 border-gold-300 shadow-md shadow-gold-500/10'
                : 'bg-neutral-900/60 text-neutral-400 border-neutral-900 hover:text-white hover:bg-neutral-850'
            }`}
          >
            {tab === 'stats' && '📊 Platform Stats'}
            {tab === 'apps' && `🔔 Applications (${pendingApps})`}
            {tab === 'users' && '👥 User Accounts'}
            {tab === 'moderation' && '⚖️ Content Moderation'}
            {tab === 'marketing' && '🎟️ Coupon Codes'}
            {tab === 'broadcast' && '📢 Broadcaster'}
          </button>
        ))}
      </div>

      {/* Stats and Metrics */}
      {activeTab === 'stats' && (
        <div className="space-y-6">
          {/* Metrics summary cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-neutral-400 font-medium">Estimated Gross Volume</span>
                <div className="p-2 bg-green-500/10 rounded-xl text-green-400 border border-green-500/20">
                  <DollarSign size={16} />
                </div>
              </div>
              <h3 className="text-2xl font-bold font-display text-white">$58,650</h3>
              <p className="text-[10px] text-green-400 flex items-center gap-1">
                <TrendingUp size={12} />
                <span>+12.4% vs previous cycle</span>
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-neutral-400 font-medium">Active Subscriptions</span>
                <div className="p-2 bg-gold-500/10 rounded-xl text-gold-400 border border-gold-500/20">
                  <Users size={16} />
                </div>
              </div>
              <h3 className="text-2xl font-bold font-display text-white">{totalSubscribers + 140}</h3>
              <p className="text-[10px] text-gold-400">Average retention rate: 94.2%</p>
            </div>

            <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-neutral-400 font-medium">Approved Creators</span>
                <div className="p-2 bg-purple-500/10 rounded-xl text-purple-400 border border-purple-500/20">
                  <UserCheck size={16} />
                </div>
              </div>
              <h3 className="text-2xl font-bold font-display text-white">{activeCreators + 3}</h3>
              <p className="text-[10px] text-purple-400">8 verification audits complete</p>
            </div>

            <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-neutral-400 font-medium">Pending Audits</span>
                <div className="p-2 bg-yellow-500/10 rounded-xl text-yellow-400 border border-yellow-500/20">
                  <ShieldAlert size={16} />
                </div>
              </div>
              <h3 className="text-2xl font-bold font-display text-white">{pendingApps}</h3>
              <p className="text-[10px] text-yellow-400">Applications awaiting approval</p>
            </div>
          </div>

          {/* Live Visitor Presence Tracker */}
          <div className="p-5 rounded-2xl bg-neutral-900/40 border border-neutral-850 space-y-4">
            <div className="flex items-center justify-between border-b border-neutral-850 pb-3">
              <div className="flex items-center gap-2">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <h4 className="font-display font-bold text-xs tracking-wider text-neutral-300 uppercase">Live Site Presence Tracker ({activePresences.filter(p => p.lastActive && (Date.now() - new Date(p.lastActive).getTime() < 40000)).length})</h4>
              </div>
              <span className="text-[9px] font-mono text-emerald-400 font-semibold uppercase bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded">
                Live Sync Active
              </span>
            </div>

            {activePresences.filter(p => p.lastActive && (Date.now() - new Date(p.lastActive).getTime() < 40000)).length === 0 ? (
              <p className="text-neutral-500 text-xs py-2 italic">No other active visitors on the platform at this second.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {activePresences
                  .filter(p => p.lastActive && (Date.now() - new Date(p.lastActive).getTime() < 40000))
                  .map((presence) => {
                    const roleColors: {[key: string]: string} = {
                      admin: 'bg-red-500/10 text-red-400 border border-red-500/20',
                      creator: 'bg-gold-500/10 text-gold-400 border border-gold-500/20',
                      member: 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20',
                      visitor: 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                    };

                    return (
                      <div key={presence.id} className="p-3 bg-neutral-950 rounded-xl border border-neutral-850 flex items-center justify-between gap-3 text-xs">
                        <div className="space-y-1 min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-white truncate max-w-[100px]" title={presence.name}>
                              {presence.name}
                            </span>
                            <span className={`px-1 py-0.2 rounded text-[7px] font-mono uppercase ${roleColors[presence.role] || 'bg-neutral-800 text-neutral-400'}`}>
                              {presence.role}
                            </span>
                          </div>
                          <p className="text-[10px] text-neutral-400 font-mono truncate max-w-[140px]">
                            {presence.email}
                          </p>
                          <p className="text-[10px] text-gold-500 font-medium truncate max-w-[140px]">
                            📍 Page: <span className="text-white font-normal">{presence.viewingPage || 'Home'}</span>
                          </p>
                        </div>
                        <span className="text-[8px] text-neutral-500 font-mono shrink-0">
                          {new Date(presence.lastActive).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                        </span>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>

          {/* SVG Charts Area */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Chart 1: Revenue progress */}
            <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-display font-semibold text-xs tracking-wider text-neutral-300 uppercase">Platform Revenue Breakdown</h4>
                <span className="text-[10px] font-mono text-neutral-400">Last 6 Months</span>
              </div>
              <div className="h-48 w-full flex items-end justify-between pt-4 pb-2 px-2 border-b border-neutral-850">
                {[
                  { month: 'Feb', rev: 14000, h: 'h-1/5' },
                  { month: 'Mar', rev: 22000, h: 'h-2/5' },
                  { month: 'Apr', rev: 31000, h: 'h-3/5' },
                  { month: 'May', rev: 44000, h: 'h-4/5' },
                  { month: 'Jun', rev: 49000, h: 'h-[85%]' },
                  { month: 'Jul', rev: 58650, h: 'h-full' }
                ].map((d, idx) => (
                  <div key={idx} className="flex flex-col items-center gap-2 w-12">
                    <div className="w-full relative flex flex-col justify-end h-32">
                      <div className={`w-6 bg-gradient-to-t from-gold-600 to-gold-400 rounded-t ${d.h} mx-auto relative group`}>
                        <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-neutral-950 border border-gold-400/30 text-[9px] text-gold-400 px-1 py-0.5 rounded opacity-0 group-hover:opacity-100 transition whitespace-nowrap z-10">
                          ${d.rev.toLocaleString()}
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-neutral-400">{d.month}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Chart 2: Category distribution */}
            <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-display font-semibold text-xs tracking-wider text-neutral-300 uppercase">Platform Subscription Distribution</h4>
                <span className="text-[10px] font-mono text-neutral-400">Active Shares</span>
              </div>
              <div className="flex items-center justify-center h-48 gap-8">
                {/* SVG Pie Representation */}
                <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 32 32">
                  <circle r="16" cx="16" cy="16" fill="transparent" stroke="#1c1917" strokeWidth="32" />
                  {/* Fashion: 45% (dasharray: 45 100) */}
                  <circle r="16" cx="16" cy="16" fill="transparent" stroke="#d4aa11" strokeWidth="32" strokeDasharray="45 100" strokeDashoffset="0" />
                  {/* Finance: 35% (dasharray: 35 100) */}
                  <circle r="16" cx="16" cy="16" fill="transparent" stroke="#7c2d12" strokeWidth="32" strokeDasharray="35 100" strokeDashoffset="-45" />
                  {/* Audio: 20% (dasharray: 20 100) */}
                  <circle r="16" cx="16" cy="16" fill="transparent" stroke="#a855f7" strokeWidth="32" strokeDasharray="20 100" strokeDashoffset="-80" />
                </svg>
                <div className="space-y-2 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-gold-500 rounded" />
                    <span className="text-neutral-300">Fashion & Travel (45%)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-orange-900 rounded" />
                    <span className="text-neutral-300">Finance & Leadership (35%)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-purple-500 rounded" />
                    <span className="text-neutral-300">Audio & Music (20%)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Creator Applications */}
      {activeTab === 'apps' && (
        <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4">
          <h4 className="font-display font-semibold text-xs tracking-wider text-neutral-300 uppercase">Incoming Creator Audits</h4>
          {applications.length === 0 ? (
            <p className="text-neutral-400 text-xs py-4">No pending applications at present.</p>
          ) : (
            <div className="space-y-4">
              {applications.map((app) => (
                <div
                  key={app.id}
                  className={`p-4 rounded-xl border transition ${
                    app.status === 'approved'
                      ? 'bg-green-950/20 border-green-500/20'
                      : app.status === 'rejected'
                      ? 'bg-red-950/20 border-red-500/20'
                      : 'bg-neutral-950 border-neutral-850'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h5 className="font-display font-bold text-sm text-white">{app.name}</h5>
                        <span className="text-xs text-neutral-400">(@{app.username})</span>
                        <span className={`px-2 py-0.5 rounded text-[9px] font-mono uppercase ${
                          app.status === 'pending' ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20' :
                          app.status === 'approved' ? 'bg-green-500/10 text-green-400 border border-green-500/20' :
                          'bg-red-500/10 text-red-400 border border-red-500/20'
                        }`}>
                          {app.status}
                        </span>
                      </div>
                      <p className="text-xs text-gold-400 mt-1 font-medium">{app.category}</p>
                      <p className="text-xs text-neutral-300 mt-1.5 leading-relaxed">{app.description}</p>
                      <div className="mt-2 text-[10px] text-neutral-400 font-mono">
                        Portfolio: <a href={app.portfolioUrl} target="_blank" rel="noreferrer" className="text-gold-400 hover:underline">{app.portfolioUrl}</a>
                      </div>
                    </div>

                    {app.status === 'pending' && (
                      <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                        <button
                          onClick={() => onApproveApplication(app.id)}
                          className="flex items-center gap-1 py-1.5 px-3 bg-green-500 hover:bg-green-600 text-neutral-950 font-semibold rounded-lg text-xs transition"
                        >
                          <Check size={14} />
                          Approve
                        </button>
                        <button
                          onClick={() => onRejectApplication(app.id)}
                          className="flex items-center gap-1 py-1.5 px-3 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg text-xs transition"
                        >
                          <X size={14} />
                          Reject
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Users management */}
      {activeTab === 'users' && (
        <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4">
          <h4 className="font-display font-semibold text-xs tracking-wider text-neutral-300 uppercase">Interactive User Sovereignty Ledger</h4>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-neutral-850 text-neutral-400 font-medium">
                  <th className="py-2.5">Supporter</th>
                  <th>Username</th>
                  <th>Current Role</th>
                  <th>Account Status</th>
                  <th className="text-right">Administration</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-900 text-neutral-200">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-neutral-850/30 transition">
                    <td className="py-3 flex items-center gap-2.5">
                      <img src={u.avatarUrl} alt={u.name} className="w-8 h-8 rounded-full border border-neutral-800" />
                      <div>
                        <span className="font-bold text-white block">{u.name}</span>
                        <span className="text-[10px] text-neutral-500 font-mono">{u.email}</span>
                      </div>
                    </td>
                    <td>@{u.username}</td>
                    <td>
                      <select
                        value={u.role}
                        onChange={(e) => onToggleUserRole(u.id, e.target.value as any)}
                        disabled={u.id === currentUser.id}
                        className="bg-neutral-950 border border-neutral-800 rounded px-2 py-1 text-xs text-white focus:outline-none focus:border-gold-500 disabled:opacity-50"
                      >
                        <option value="member">Member</option>
                        <option value="creator">Creator</option>
                        <option value="admin">Admin</option>
                      </select>
                    </td>
                    <td>
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-mono ${
                        u.status === 'active' ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'
                      }`}>
                        {u.status}
                      </span>
                    </td>
                    <td className="text-right">
                      {u.id !== currentUser.id ? (
                        <button
                          onClick={() => onToggleUserStatus(u.id)}
                          className={`p-1.5 rounded transition ${
                            u.status === 'active'
                              ? 'text-red-400 hover:bg-red-500/10'
                              : 'text-green-400 hover:bg-green-500/10'
                          }`}
                          title={u.status === 'active' ? 'Suspend User' : 'Activate User'}
                        >
                          {u.status === 'active' ? <Ban size={14} /> : <UserCheck size={14} />}
                        </button>
                      ) : (
                        <span className="text-[10px] text-neutral-500 font-mono">Self Sovereign</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Moderation */}
      {activeTab === 'moderation' && (
        <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4">
          <h4 className="font-display font-semibold text-xs tracking-wider text-neutral-300 uppercase">Community Content Moderation Deck</h4>
          {communityPosts.length === 0 ? (
            <p className="text-neutral-400 text-xs py-4">No community discussions present.</p>
          ) : (
            <div className="space-y-4">
              {communityPosts.map((post) => (
                <div key={post.id} className="p-4 rounded-xl bg-neutral-950 border border-neutral-850 flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="px-2 py-0.5 rounded bg-neutral-900 text-gold-400 text-[9px] font-mono uppercase">{post.category}</span>
                      <h5 className="font-display font-bold text-xs text-white">{post.title}</h5>
                      {post.reportsCount > 0 && (
                        <span className="px-1.5 py-0.5 bg-red-500/10 text-red-400 border border-red-500/20 text-[9px] font-mono flex items-center gap-1 rounded">
                          <AlertTriangle size={10} />
                          {post.reportsCount} Reports
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-neutral-400 mt-1 line-clamp-1">"{post.content}"</p>
                    <span className="text-[10px] text-neutral-500 mt-1 block font-mono">By @{post.username} on {post.date}</span>
                  </div>
                  <button
                    onClick={() => onDeleteCommunityPost(post.id)}
                    className="self-end md:self-auto p-1.5 text-red-400 hover:bg-red-500/10 rounded-lg transition"
                    title="Remove Post"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Marketing / Coupon */}
      {activeTab === 'marketing' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4 md:col-span-1">
            <h4 className="font-display font-semibold text-xs tracking-wider text-neutral-300 uppercase">Construct Coupon</h4>
            <form onSubmit={handleAddCouponSubmit} className="space-y-3">
              <div>
                <label className="block text-[10px] font-medium text-neutral-400 mb-1">Coupon Code</label>
                <input
                  type="text"
                  required
                  placeholder="HUBVIP50"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition font-mono uppercase"
                />
              </div>

              <div>
                <label className="block text-[10px] font-medium text-neutral-400 mb-1">Discount Metric</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCouponType('percent')}
                    className={`py-1.5 rounded-lg text-xs font-semibold border transition ${
                      couponType === 'percent' ? 'bg-gold-500 text-neutral-950 border-gold-300' : 'bg-neutral-950 text-neutral-400 border-neutral-850'
                    }`}
                  >
                    Percentage (%)
                  </button>
                  <button
                    type="button"
                    onClick={() => setCouponType('fixed')}
                    className={`py-1.5 rounded-lg text-xs font-semibold border transition ${
                      couponType === 'fixed' ? 'bg-gold-500 text-neutral-950 border-gold-300' : 'bg-neutral-950 text-neutral-400 border-neutral-850'
                    }`}
                  >
                    Fixed Amount ($)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-medium text-neutral-400 mb-1">Discount Value</label>
                <input
                  type="number"
                  required
                  min={1}
                  value={couponValue}
                  onChange={(e) => setCouponValue(Math.max(1, parseInt(e.target.value) || 0))}
                  className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-gradient-to-r from-gold-600 to-gold-400 text-neutral-950 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition"
              >
                <Plus size={14} />
                Inject Coupon
              </button>
            </form>
          </div>

          <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4 md:col-span-2">
            <h4 className="font-display font-semibold text-xs tracking-wider text-neutral-300 uppercase">Active Promotion Codes</h4>
            <div className="space-y-3">
              {coupons.map((c) => (
                <div key={c.id} className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-850 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-gold-500/10 text-gold-400 border border-gold-400/20 rounded-xl">
                      <Ticket size={18} />
                    </div>
                    <div>
                      <span className="font-mono font-bold text-white text-sm">{c.code}</span>
                      <span className="block text-[10px] text-neutral-400">
                        Entitles supporter to {c.discountType === 'percent' ? `${c.value}% off` : `$${c.value} off`} subscriptions
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => onDeleteCoupon(c.id)}
                    className="p-1.5 text-neutral-500 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition"
                    title="Revoke Promo"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Broadcast messages */}
      {activeTab === 'broadcast' && (
        <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-display font-semibold text-xs tracking-wider text-neutral-300 uppercase">Broadcast Platform Notification</h4>
            <Megaphone size={16} className="text-gold-400" />
          </div>

          {successMsg && (
            <div className="p-3 rounded-xl bg-green-950/30 border border-green-500/20 text-green-300 text-xs flex items-center gap-2">
              <Check size={16} className="text-green-400 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          <form onSubmit={handleBroadcastSubmit} className="space-y-4">
            <div>
              <label className="block text-[11px] font-medium text-neutral-400 mb-1">Headline</label>
              <input
                type="text"
                required
                placeholder="Platform Maintenance / Promotion Event Coordinates"
                value={announceTitle}
                onChange={(e) => setAnnounceTitle(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-neutral-400 mb-1">Detailed Message Content</label>
              <textarea
                required
                rows={4}
                placeholder="Broadcast information details dispatched directly to all platform users..."
                value={announceBody}
                onChange={(e) => setAnnounceBody(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2.5 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition resize-none"
              />
            </div>

            <button
              type="submit"
              className="py-2.5 px-5 bg-gradient-to-r from-gold-600 to-gold-400 text-neutral-950 font-display font-bold rounded-xl text-xs transition active:scale-98"
            >
              Dispatch System-Wide Broadcast
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
