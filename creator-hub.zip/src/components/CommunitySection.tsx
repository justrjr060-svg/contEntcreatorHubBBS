import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  MessageSquare,
  Heart,
  Pin,
  Flag,
  Trash2,
  Plus,
  Search,
  Filter,
  Check,
  Send,
  Sparkles,
  Award
} from 'lucide-react';
import { CommunityPost, User, Comment } from '../types';

interface CommunitySectionProps {
  currentUser: User | null;
  posts: CommunityPost[];
  onAddPost: (title: string, content: string, category: string) => void;
  onLikePost: (postId: string) => void;
  onReportPost: (postId: string) => void;
  onDeletePost: (postId: string) => void;
  onAddComment: (postId: string, content: string) => void;
  onOpenAuth: () => void;
}

export default function CommunitySection({
  currentUser,
  posts,
  onAddPost,
  onLikePost,
  onReportPost,
  onDeletePost,
  onAddComment,
  onOpenAuth
}: CommunitySectionProps) {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreatingPost, setIsCreatingPost] = useState(false);

  // New Post Form
  const [postTitle, setPostTitle] = useState('');
  const [postContent, setPostContent] = useState('');
  const [postCategory, setPostCategory] = useState('general');

  // Comment inputs mapped by post ID
  const [commentInputs, setCommentInputs] = useState<{ [postId: string]: string }>({});

  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (!postTitle.trim() || !postContent.trim()) return;

    onAddPost(postTitle, postContent, postCategory);
    setPostTitle('');
    setPostContent('');
    setPostCategory('general');
    setIsCreatingPost(false);
  };

  const handleCommentSubmit = (e: React.FormEvent, postId: string) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    const commentText = commentInputs[postId];
    if (!commentText || !commentText.trim()) return;

    onAddComment(postId, commentText);
    setCommentInputs((prev) => ({ ...prev, [postId]: '' }));
  };

  const categories = [
    { id: 'all', label: '✨ All Coordinates' },
    { id: 'general', label: '💬 General' },
    { id: 'qa', label: '❓ Q&A' },
    { id: 'announcement', label: '📢 Broadcasts' },
    { id: 'collab', label: '🤝 Collaborations' }
  ];

  const filteredPosts = posts
    .filter((post) => {
      if (activeCategory !== 'all' && post.category !== activeCategory) return false;
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return (
          post.title.toLowerCase().includes(query) ||
          post.content.toLowerCase().includes(query) ||
          post.username.toLowerCase().includes(query)
        );
      }
      return true;
    })
    // Sort pinned posts first, then newest
    .sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return new Date(b.date).getTime() - new Date(a.date).getTime();
    });

  return (
    <div id="community-section" className="space-y-6 text-white">
      {/* Title Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-neutral-900 pb-5">
        <div>
          <h2 className="font-display text-2xl font-bold tracking-tight">
            VIP Supporter <span className="gold-gradient-text">Forum</span>
          </h2>
          <p className="text-neutral-400 text-xs mt-1">
            Establish threads, exchange video concepts, apply for platform partnerships, or request sound designs.
          </p>
        </div>

        <button
          onClick={() => {
            if (!currentUser) {
              onOpenAuth();
            } else {
              setIsCreatingPost(!isCreatingPost);
            }
          }}
          className="flex items-center gap-1.5 self-start md:self-auto py-2 px-4 rounded-xl bg-gradient-to-r from-gold-600 to-gold-400 text-neutral-950 font-display font-bold text-xs hover:opacity-95 transition"
        >
          <Plus size={16} />
          Create New Thread
        </button>
      </div>

      {/* New Post Creator Panel */}
      <AnimatePresence>
        {isCreatingPost && currentUser && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <form onSubmit={handlePostSubmit} className="p-5 rounded-2xl bg-neutral-900/40 border border-gold-400/20 space-y-4">
              <h4 className="font-display font-semibold text-xs text-gold-400 uppercase tracking-wider">Broadcasting Coordinates</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="md:col-span-2">
                  <label className="block text-[10px] text-neutral-400 mb-1 font-medium">Thread Headline</label>
                  <input
                    type="text"
                    required
                    placeholder="Enter discussion topic..."
                    value={postTitle}
                    onChange={(e) => setPostTitle(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1 font-medium">Categorization</label>
                  <select
                    value={postCategory}
                    onChange={(e) => setPostCategory(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition"
                  >
                    <option value="general">💬 General Conversation</option>
                    <option value="qa">❓ Question & Answer</option>
                    <option value="collab">🤝 Brand Collaboration</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-neutral-400 mb-1 font-medium">Message Body</label>
                <textarea
                  required
                  rows={4}
                  placeholder="Share details, coordinates, or media ideas with other members..."
                  value={postContent}
                  onChange={(e) => setPostContent(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition resize-none"
                />
              </div>

              <div className="flex justify-end gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setIsCreatingPost(false)}
                  className="px-4 py-2 bg-neutral-800 hover:bg-neutral-750 text-neutral-300 rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gradient-to-r from-gold-600 to-gold-400 text-neutral-950 font-bold rounded-xl transition"
                >
                  Transmit Thread
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`py-1.5 px-3 rounded-xl text-[11px] font-medium transition shrink-0 border ${
                activeCategory === cat.id
                  ? 'bg-gold-500/10 text-gold-400 border-gold-400/30'
                  : 'bg-neutral-950 text-neutral-400 border-neutral-900 hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64 shrink-0">
          <Search className="absolute left-3 top-2.5 text-neutral-500" size={14} />
          <input
            type="text"
            placeholder="Search discussions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-neutral-950 border border-neutral-900 rounded-xl py-1.5 pl-9 pr-3 text-xs text-white focus:outline-none focus:border-gold-500 transition"
          />
        </div>
      </div>

      {/* Discussions Feed */}
      <div className="space-y-4">
        {filteredPosts.length === 0 ? (
          <div className="p-8 text-center bg-neutral-950 rounded-2xl border border-neutral-900 text-neutral-400 text-xs">
            No threads align with your filters. Be the first to coordinate a topic!
          </div>
        ) : (
          filteredPosts.map((post) => {
            const hasLiked = currentUser && post.likedBy?.includes(currentUser.id);
            return (
              <div
                key={post.id}
                className={`p-5 rounded-2xl bg-neutral-950 border shadow-md transition flex flex-col gap-4 ${
                  post.isPinned ? 'border-gold-400/30 bg-neutral-950/80' : 'border-neutral-900'
                }`}
              >
                {/* Author Info header */}
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-2.5">
                    <img
                      src={post.avatarUrl}
                      alt={post.username}
                      className="w-8 h-8 rounded-full border border-neutral-850 object-cover"
                    />
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-bold text-xs text-white">{post.username}</span>
                        {post.isPinned && (
                          <span className="flex items-center gap-0.5 text-[9px] text-gold-400 bg-gold-400/10 border border-gold-400/20 px-1.5 py-0.2 rounded font-semibold">
                            <Pin size={8} />
                            Pinned
                          </span>
                        )}
                        <span className="text-[10px] text-neutral-500 font-mono">{post.date}</span>
                      </div>
                      <span className="text-[9px] bg-neutral-900 text-gold-400 px-1.5 py-0.2 border border-neutral-850 font-mono uppercase rounded">
                        {post.category}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => {
                        if (!currentUser) onOpenAuth();
                        else onReportPost(post.id);
                      }}
                      className="p-1.5 text-neutral-500 hover:text-orange-400 hover:bg-neutral-900 rounded-lg transition"
                      title="Report thread"
                    >
                      <Flag size={12} />
                    </button>
                    {(currentUser?.id === post.userId || currentUser?.role === 'admin') && (
                      <button
                        onClick={() => onDeletePost(post.id)}
                        className="p-1.5 text-neutral-500 hover:text-red-400 hover:bg-neutral-900 rounded-lg transition"
                        title="Delete thread"
                      >
                        <Trash2 size={12} />
                      </button>
                    )}
                  </div>
                </div>

                {/* Body Content */}
                <div className="space-y-1.5">
                  <h3 className="font-display font-bold text-sm text-white group-hover:text-gold-300 transition">
                    {post.title}
                  </h3>
                  <p className="text-xs text-neutral-300 leading-relaxed whitespace-pre-line">
                    {post.content}
                  </p>
                </div>

                {/* Footer Likes / Comments Toggle status */}
                <div className="flex items-center gap-4 text-xs border-y border-neutral-900 py-2.5">
                  <button
                    onClick={() => {
                      if (!currentUser) onOpenAuth();
                      else onLikePost(post.id);
                    }}
                    className={`flex items-center gap-1.5 transition ${
                      hasLiked ? 'text-gold-400 font-semibold' : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    <Heart size={14} fill={hasLiked ? 'currentColor' : 'none'} />
                    <span>{post.likes} Likes</span>
                  </button>

                  <div className="flex items-center gap-1.5 text-neutral-400">
                    <MessageSquare size={14} />
                    <span>{post.comments.length} comments</span>
                  </div>
                </div>

                {/* Comment list thread */}
                {post.comments.length > 0 && (
                  <div className="space-y-3 pl-4 border-l-2 border-neutral-900 mt-1">
                    {post.comments.map((comment) => (
                      <div key={comment.id} className="text-xs space-y-1">
                        <div className="flex items-center gap-2">
                          <img
                            src={comment.avatarUrl}
                            alt={comment.username}
                            className="w-5.5 h-5.5 rounded-full object-cover border border-neutral-850"
                          />
                          <span className="font-bold text-[11px] text-white">@{comment.username}</span>
                          <span className="text-[9px] text-neutral-500 font-mono">{comment.date}</span>
                        </div>
                        <p className="text-neutral-300 leading-relaxed pl-7">{comment.content}</p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Post comment input */}
                <form onSubmit={(e) => handleCommentSubmit(e, post.id)} className="flex gap-2">
                  <input
                    type="text"
                    placeholder={currentUser ? 'Write a private comment...' : 'Log in to leave comments'}
                    value={commentInputs[post.id] || ''}
                    disabled={!currentUser}
                    onChange={(e) => setCommentInputs((prev) => ({ ...prev, [post.id]: e.target.value }))}
                    className="flex-1 bg-neutral-900 border border-neutral-850 rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:border-gold-500 text-white disabled:opacity-50"
                  />
                  <button
                    type="submit"
                    disabled={!currentUser}
                    className="py-1.5 px-3 rounded-xl bg-neutral-900 border border-neutral-850 hover:bg-gold-500 hover:text-neutral-950 hover:border-transparent text-neutral-300 text-xs font-semibold flex items-center gap-1 transition disabled:opacity-50"
                  >
                    <Send size={12} />
                  </button>
                </form>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
