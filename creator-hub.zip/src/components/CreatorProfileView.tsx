import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  Lock,
  Unlock,
  CheckCircle,
  Play,
  Heart,
  MessageSquare,
  Share2,
  Bookmark,
  Briefcase,
  QrCode,
  Copy,
  Check,
  CreditCard,
  Ticket,
  ChevronRight,
  Send
} from 'lucide-react';
import { Creator, User, ContentItem, Plan, Payment } from '../types';

interface CreatorProfileViewProps {
  creator: Creator;
  currentUser: User | null;
  onSubscribe: (creatorId: string, plan: Plan, couponCode?: string) => void;
  onUnsubscribe: (creatorId: string) => void;
  onLikePost: (postId: string) => void;
  onAddComment: (postId: string, commentContent: string) => void;
  onAddCollabProposal: (proposedBudget: number, message: string) => void;
  onOpenAuth: () => void;
  isFavorite: boolean;
  onToggleFavorite: (creatorId: string) => void;
}

export default function CreatorProfileView({
  creator,
  currentUser,
  onSubscribe,
  onUnsubscribe,
  onLikePost,
  onAddComment,
  onAddCollabProposal,
  onOpenAuth,
  isFavorite,
  onToggleFavorite
}: CreatorProfileViewProps) {
  const [activeTab, setActiveTab] = useState<'feed' | 'plans' | 'collab' | 'about'>('feed');
  const [checkoutPlan, setCheckoutPlan] = useState<Plan | null>(null);
  const [activeGateway, setActiveGateway] = useState<'stripe' | 'paypal' | 'whatsapp'>('stripe');

  // Stripe Checkout state
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [couponCode, setCouponCode] = useState('');
  const [appliedCouponValue, setAppliedCouponValue] = useState<number>(0);
  const [couponStatus, setCouponStatus] = useState<'none' | 'success' | 'invalid'>('none');
  const [paymentError, setPaymentError] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  // Collaboration Proposal form
  const [collabBudget, setCollabBudget] = useState<number>(2500);
  const [collabMessage, setCollabMessage] = useState('');
  const [collabSuccess, setCollabSuccess] = useState('');

  // Share profile state
  const [isSharing, setIsSharing] = useState(false);
  const [copied, setCopied] = useState(false);

  // Comment inputs mapped by post ID
  const [feedCommentInputs, setFeedCommentInputs] = useState<{ [postId: string]: string }>({});

  // Active user subscription status for this creator
  const userSub = currentUser?.activeSubscriptions[creator.id];
  const userTier = userSub?.status === 'active' ? userSub.tier : 0; // 0 = Public

  const handleApplyCoupon = () => {
    const code = couponCode.toUpperCase().trim();
    if (code === 'HUBGOLD10') {
      setAppliedCouponValue(10); // 10%
      setCouponStatus('success');
    } else if (code === 'LUXURYVIP') {
      setAppliedCouponValue(5); // $5 flat off
      setCouponStatus('success');
    } else {
      setCouponStatus('invalid');
      setAppliedCouponValue(0);
    }
  };

  const getDiscountedPrice = (price: number) => {
    if (couponStatus !== 'success') return price;
    if (couponCode.toUpperCase().trim() === 'HUBGOLD10') {
      return Math.max(0, parseFloat((price * 0.9).toFixed(2)));
    } else if (couponCode.toUpperCase().trim() === 'LUXURYVIP') {
      return Math.max(0, parseFloat((price - 5).toFixed(2)));
    }
    return price;
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPaymentError('');

    if (activeGateway !== 'whatsapp' && (!cardNumber || !cardExpiry || !cardCvv)) {
      setPaymentError('Please fill out card details to authorize transaction.');
      return;
    }
    if (activeGateway === 'whatsapp' && !cardNumber.trim()) {
      setPaymentError('Please enter the WhatsApp payment transaction reference ID.');
      return;
    }

    setIsProcessing(true);

    setTimeout(() => {
      setIsProcessing(false);
      setPaymentSuccess(true);
      setTimeout(() => {
        onSubscribe(creator.id, checkoutPlan!, couponStatus === 'success' ? couponCode : undefined);
        setCheckoutPlan(null);
        setPaymentSuccess(false);
        setCouponCode('');
        setCouponStatus('none');
        setAppliedCouponValue(0);
        setCardNumber('');
        setCardExpiry('');
        setCardCvv('');
        setActiveGateway('stripe');
      }, 1500);
    }, 2000);
  };

  const handleCollabSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (!collabMessage.trim() || collabBudget <= 0) return;

    onAddCollabProposal(collabBudget, collabMessage);
    setCollabBudget(2500);
    setCollabMessage('');
    setCollabSuccess('Your platform sponsorship proposal has been dispatched to the Creator!');
    setTimeout(() => setCollabSuccess(''), 4000);
  };

  const handleCopyProfileLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCommentSubmit = (e: React.FormEvent, postId: string) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    const txt = feedCommentInputs[postId];
    if (!txt || !txt.trim()) return;

    onAddComment(postId, txt);
    setFeedCommentInputs((prev) => ({ ...prev, [postId]: '' }));
  };

  return (
    <div id={`creator-profile-${creator.id}`} className="space-y-6 text-white pb-12">
      {/* Dynamic Back to List top control */}
      <div className="relative h-48 md:h-64 rounded-3xl overflow-hidden border border-neutral-900">
        <img
          src={creator.bannerUrl}
          alt={creator.name}
          className="w-full h-full object-cover brightness-50"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/40 to-transparent" />
        <div className="absolute top-4 right-4 flex items-center gap-2">
          <button
            onClick={() => onToggleFavorite(creator.id)}
            className="p-2 rounded-full bg-black/60 border border-neutral-850 backdrop-blur-sm text-gold-400 hover:scale-105 active:scale-95 transition"
          >
            {isFavorite ? '★ Favorited' : '☆ Favorite'}
          </button>
          <button
            onClick={() => setIsSharing(true)}
            className="p-2 rounded-full bg-black/60 border border-neutral-850 backdrop-blur-sm text-white hover:scale-105 active:scale-95 transition flex items-center gap-1.5 text-xs font-semibold"
          >
            <Share2 size={14} />
            Share Coordinates
          </button>
        </div>
      </div>

      {/* Profile Overview Card */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-5 -mt-20 relative z-10 px-6">
        <div className="flex flex-col md:flex-row items-center md:items-end gap-4 text-center md:text-left">
          <img
            src={creator.avatarUrl}
            alt={creator.name}
            className="w-28 h-28 rounded-full border-4 border-gold-400 object-cover bg-neutral-950 shadow-xl"
          />
          <div className="md:mb-3">
            <h2 className="font-display font-bold text-2xl text-white tracking-tight flex items-center justify-center md:justify-start gap-2">
              {creator.name}
              <CheckCircle size={18} className="text-gold-400 fill-neutral-950 shrink-0" />
            </h2>
            <p className="text-xs text-neutral-400 mt-0.5">
              @{creator.username} • <span className="text-gold-400 font-semibold">{creator.category}</span>
            </p>
          </div>
        </div>

        {/* Subscription state display in general header */}
        <div className="self-center md:self-auto flex flex-col items-center md:items-end gap-1.5">
          <span className="text-[10px] text-neutral-400 font-mono">My Subscription Level</span>
          {userTier > 0 ? (
            <div className="flex items-center gap-2">
              <span className="px-3.5 py-1.5 rounded-xl bg-gold-500 text-neutral-950 font-display font-bold text-xs uppercase shadow-md shadow-gold-500/15">
                {userTier === 1 && '🥉 Bronze Supporter'}
                {userTier === 2 && '🥈 Silver VIP'}
                {userTier === 3 && '👑 Gold VIP Inner Circle'}
              </span>
              <button
                onClick={() => onUnsubscribe(creator.id)}
                className="text-[11px] text-red-400 hover:underline"
              >
                Cancel Subscription
              </button>
            </div>
          ) : (
            <button
              onClick={() => {
                if (!currentUser) onOpenAuth();
                else setActiveTab('plans');
              }}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-gold-600 to-gold-400 text-neutral-950 font-display font-bold text-xs shadow-lg shadow-gold-500/10 active:scale-98 transition"
            >
              Subscribe and Unlock Feed
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-neutral-900 pb-1 text-xs">
        <button
          onClick={() => setActiveTab('feed')}
          className={`pb-2 px-5 font-semibold transition border-b-2 ${
            activeTab === 'feed' ? 'text-gold-400 border-gold-400' : 'text-neutral-400 hover:text-white border-transparent'
          }`}
        >
          Publications Feed
        </button>
        <button
          onClick={() => setActiveTab('plans')}
          className={`pb-2 px-5 font-semibold transition border-b-2 ${
            activeTab === 'plans' ? 'text-gold-400 border-gold-400' : 'text-neutral-400 hover:text-white border-transparent'
          }`}
        >
          Membership Plans
        </button>
        <button
          onClick={() => setActiveTab('collab')}
          className={`pb-2 px-5 font-semibold transition border-b-2 ${
            activeTab === 'collab' ? 'text-gold-400 border-gold-400' : 'text-neutral-400 hover:text-white border-transparent'
          }`}
        >
          Sponsorship pitch
        </button>
        <button
          onClick={() => setActiveTab('about')}
          className={`pb-2 px-5 font-semibold transition border-b-2 ${
            activeTab === 'about' ? 'text-gold-400 border-gold-400' : 'text-neutral-400 hover:text-white border-transparent'
          }`}
        >
          Biography
        </button>
      </div>

      {/* Tab: Feed */}
      {activeTab === 'feed' && (
        <div className="grid grid-cols-1 gap-6">
          {creator.posts.map((post) => {
            const isGated = post.minTier > userTier;
            return (
              <div
                key={post.id}
                className="p-5 rounded-2xl bg-neutral-950 border border-neutral-900 shadow-md flex flex-col gap-4 relative overflow-hidden"
              >
                {/* Locked Blur layer if gated */}
                {isGated && (
                  <div className="absolute inset-0 bg-neutral-950/80 backdrop-blur-md z-20 flex flex-col items-center justify-center p-6 text-center">
                    <div className="h-12 w-12 rounded-full bg-gold-500/10 border border-gold-400/20 text-gold-400 flex items-center justify-center mb-3">
                      <Lock size={20} />
                    </div>
                    <h4 className="font-display font-bold text-sm text-white">Locked Premium Publication</h4>
                    <p className="text-neutral-400 text-xs mt-1 max-w-sm">
                      This content requires a minimum of <strong className="text-gold-400">{post.minTier === 1 ? 'Bronze Plan' : post.minTier === 2 ? 'Silver Plan' : 'Gold Plan'}</strong> or higher to unlock.
                    </p>
                    <button
                      onClick={() => setActiveTab('plans')}
                      className="mt-4 px-4 py-1.5 bg-gradient-to-r from-gold-600 to-gold-400 text-neutral-950 font-bold rounded-lg text-xs hover:opacity-90 transition"
                    >
                      Unlock Now
                    </button>
                  </div>
                )}

                {/* Post Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] bg-neutral-900 border border-neutral-850 px-2 py-0.5 rounded font-mono uppercase text-neutral-400">
                      {post.type}
                    </span>
                    <span className="text-[10px] text-neutral-500 font-mono">{post.date}</span>
                  </div>
                  <span className="text-xs text-gold-400 font-semibold flex items-center gap-1">
                    <Unlock size={12} />
                    Access: Unlocked
                  </span>
                </div>

                {/* Media Image or video placeholder */}
                {post.mediaUrl && (
                  <div className="relative h-64 sm:h-96 rounded-xl overflow-hidden border border-neutral-900 bg-neutral-900 flex items-center justify-center">
                    <img
                      src={post.mediaUrl}
                      alt={post.title}
                      className="w-full h-full object-cover"
                    />
                    {post.type === 'video' && (
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        <button className="h-16 w-16 rounded-full bg-gold-400 text-neutral-950 flex items-center justify-center hover:scale-105 active:scale-95 transition shadow-lg shadow-gold-500/15">
                          <Play size={24} fill="currentColor" className="ml-1" />
                        </button>
                        <span className="absolute bottom-3 right-3 bg-black/70 border border-neutral-850 text-[10px] font-mono px-2 py-0.5 rounded text-white">
                          Video: {post.duration}
                        </span>
                      </div>
                    )}
                  </div>
                )}

                {/* Article text for blog */}
                <div className="space-y-1.5">
                  <h3 className="font-display font-bold text-base text-white">{post.title}</h3>
                  <p className="text-xs text-neutral-300 leading-relaxed">{post.description}</p>
                  {post.body && (
                    <div className="mt-3 text-xs text-neutral-400 whitespace-pre-line leading-relaxed bg-neutral-900/40 border border-neutral-900 p-4 rounded-xl">
                      {post.body}
                    </div>
                  )}
                </div>

                {/* Like and comment stats */}
                <div className="flex items-center gap-4 text-xs border-y border-neutral-900 py-2.5">
                  <button
                    onClick={() => {
                      if (!currentUser) onOpenAuth();
                      else onLikePost(post.id);
                    }}
                    className={`flex items-center gap-1.5 text-neutral-400 hover:text-white transition`}
                  >
                    <Heart size={14} />
                    <span>{post.likes} Likes</span>
                  </button>
                  <div className="flex items-center gap-1.5 text-neutral-400">
                    <MessageSquare size={14} />
                    <span>{post.comments.length} Comments</span>
                  </div>
                </div>

                {/* Comments Thread */}
                {post.comments.length > 0 && (
                  <div className="space-y-3.5 pl-4 border-l-2 border-neutral-900 mt-1">
                    {post.comments.map((c) => (
                      <div key={c.id} className="text-xs space-y-1">
                        <div className="flex items-center gap-2">
                          <img
                            src={c.avatarUrl}
                            alt={c.username}
                            className="w-5.5 h-5.5 rounded-full object-cover"
                          />
                          <span className="font-bold text-white">@{c.username}</span>
                          <span className="text-[9px] text-neutral-500 font-mono">{c.date}</span>
                        </div>
                        <p className="text-neutral-300 leading-relaxed pl-7">{c.content}</p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Add comment Form */}
                <form onSubmit={(e) => handleCommentSubmit(e, post.id)} className="flex gap-2">
                  <input
                    type="text"
                    required
                    placeholder={currentUser ? 'Leave your support note...' : 'Log in to leave comments'}
                    value={feedCommentInputs[post.id] || ''}
                    disabled={!currentUser}
                    onChange={(e) => setFeedCommentInputs((prev) => ({ ...prev, [post.id]: e.target.value }))}
                    className="flex-1 bg-neutral-900 border border-neutral-850 rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:border-gold-500 text-white disabled:opacity-50"
                  />
                  <button
                    type="submit"
                    disabled={!currentUser}
                    className="p-1.5 rounded-xl bg-neutral-900 border border-neutral-850 hover:bg-gold-500 hover:text-neutral-950 hover:border-transparent text-neutral-300 transition"
                  >
                    <Send size={12} />
                  </button>
                </form>
              </div>
            );
          })}
        </div>
      )}

      {/* Tab: Plans */}
      {activeTab === 'plans' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {creator.plans.map((plan) => {
            const isCurrentPlan = userTier === plan.tier;
            return (
              <div
                key={plan.id}
                className={`p-6 rounded-2xl border transition flex flex-col h-full text-white relative ${
                  isCurrentPlan
                    ? 'border-gold-400 bg-gold-400/5 shadow-[0_0_30px_rgba(212,170,17,0.15)]'
                    : 'border-neutral-900 bg-neutral-950 hover:border-neutral-800'
                }`}
              >
                {/* Active plan badge */}
                {isCurrentPlan && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full bg-gold-400 text-neutral-950 font-mono font-bold text-[9px] uppercase tracking-wider">
                    My Current Perks
                  </span>
                )}

                <div className="mb-4">
                  <h4 className="font-display font-bold text-base text-white">{plan.title}</h4>
                  <p className="text-neutral-400 text-xs mt-1 leading-relaxed min-h-[40px]">{plan.description}</p>
                </div>

                <div className="mb-6 flex items-baseline gap-1">
                  <span className="text-3xl font-display font-bold text-gold-400">${plan.price}</span>
                  <span className="text-xs text-neutral-400 font-medium">/{plan.interval}</span>
                </div>

                <ul className="space-y-3 mb-8 text-xs text-neutral-300 flex-1">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle size={14} className="text-gold-400 shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => {
                    if (!currentUser) onOpenAuth();
                    else if (isCurrentPlan) onUnsubscribe(creator.id);
                    else setCheckoutPlan(plan);
                  }}
                  className={`w-full py-2.5 rounded-xl font-display font-bold text-xs transition duration-200 ${
                    isCurrentPlan
                      ? 'bg-neutral-900 text-red-400 hover:bg-neutral-850'
                      : 'bg-gradient-to-r from-gold-600 to-gold-400 text-neutral-950'
                  }`}
                >
                  {isCurrentPlan ? 'Cancel Perks' : 'Select Perks'}
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Tab: Collaboration pitch */}
      {activeTab === 'collab' && (
        <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4">
          <div className="flex items-center gap-2">
            <Briefcase className="text-gold-400" size={18} />
            <h4 className="font-display font-semibold text-xs tracking-wider text-neutral-300 uppercase">Sponsorship Deal Proposals</h4>
          </div>

          <p className="text-neutral-400 text-xs">
            Pitch bespoke digital collaborations, custom reviews, runway features, or exclusive product lines. Establish terms and specify budget ranges.
          </p>

          {collabSuccess && (
            <div className="p-3 bg-green-950/20 border border-green-500/20 text-green-300 text-xs rounded-xl flex items-center gap-2">
              <CheckCircle size={16} className="text-green-400 shrink-0" />
              <span>{collabSuccess}</span>
            </div>
          )}

          <form onSubmit={handleCollabSubmit} className="space-y-4">
            <div>
              <label className="block text-[11px] font-medium text-neutral-400 mb-1">Proposed Project Budget (USD)</label>
              <input
                type="number"
                required
                min={100}
                value={collabBudget}
                onChange={(e) => setCollabBudget(Math.max(1, parseInt(e.target.value) || 0))}
                className="w-full max-w-xs bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition font-mono font-bold text-gold-400"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-neutral-400 mb-1">Proposal Coordinates / Description</label>
              <textarea
                required
                rows={5}
                placeholder="Detail terms, product reviews, required files, and deliverables..."
                value={collabMessage}
                onChange={(e) => setCollabMessage(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2.5 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition resize-none"
              />
            </div>

            <button
              type="submit"
              className="py-2.5 px-5 bg-gradient-to-r from-gold-600 to-gold-400 text-neutral-950 font-display font-bold rounded-xl text-xs transition"
            >
              Dispatch Proposal
            </button>
          </form>
        </div>
      )}

      {/* Tab: About biography */}
      {activeTab === 'about' && (
        <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4 leading-relaxed">
          <h4 className="font-display font-semibold text-xs tracking-wider text-neutral-300 uppercase">Creator Bio details</h4>
          <p className="text-xs text-neutral-300 whitespace-pre-line">{creator.bio}</p>

          <div className="pt-4 border-t border-neutral-900 flex flex-wrap gap-3">
            {creator.socialLinks.twitter && (
              <a
                href={creator.socialLinks.twitter}
                target="_blank"
                rel="noreferrer"
                className="py-1.5 px-3 rounded-lg bg-neutral-950 border border-neutral-850 text-xs text-neutral-400 hover:text-white transition"
              >
                𝕏 Twitter
              </a>
            )}
            {creator.socialLinks.instagram && (
              <a
                href={creator.socialLinks.instagram}
                target="_blank"
                rel="noreferrer"
                className="py-1.5 px-3 rounded-lg bg-neutral-950 border border-neutral-850 text-xs text-neutral-400 hover:text-white transition"
              >
                📸 Instagram
              </a>
            )}
            {creator.socialLinks.youtube && (
              <a
                href={creator.socialLinks.youtube}
                target="_blank"
                rel="noreferrer"
                className="py-1.5 px-3 rounded-lg bg-neutral-950 border border-neutral-850 text-xs text-neutral-400 hover:text-white transition"
              >
                🎥 YouTube Channel
              </a>
            )}
          </div>
        </div>
      )}

      {/* Check-Out Gated Modal Overlay */}
      <AnimatePresence>
        {checkoutPlan && (
          <div id="checkout-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-md rounded-3xl border border-gold-400/30 bg-neutral-950 p-8 text-white shadow-xl max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="flex justify-between items-center mb-4">
                <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-gold-400">Secure Vault Checkout</span>
                <button
                  onClick={() => setCheckoutPlan(null)}
                  className="text-neutral-500 hover:text-white text-xs"
                >
                  Cancel
                </button>
              </div>

              <h3 className="font-display font-bold text-lg text-white mb-1">
                Subscribe to {creator.name}
              </h3>
              <p className="text-[11px] text-neutral-400 mb-4">
                Select your billing channel. All transactions are securely audited and compiled.
              </p>

              {/* Recalculated pricing summary */}
              <div className="p-4 bg-neutral-900 border border-neutral-850 rounded-xl space-y-2.5 mb-5 text-xs">
                <div className="flex justify-between font-semibold text-white">
                  <span>Selected Level:</span>
                  <span>{checkoutPlan.title}</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>Subscription Value:</span>
                  <span>${checkoutPlan.price} / mo</span>
                </div>

                {couponStatus === 'success' && (
                  <div className="flex justify-between text-green-400 text-[11px] font-medium">
                    <span>Discount applied ({couponCode.toUpperCase()}):</span>
                    <span>-{couponCode.toUpperCase() === 'HUBGOLD10' ? '10%' : '$5.00'}</span>
                  </div>
                )}

                <div className="border-t border-neutral-800 pt-2.5 flex justify-between font-bold text-white text-sm">
                  <span>Authorized Charge:</span>
                  <span className="text-gold-400">${getDiscountedPrice(checkoutPlan.price)} USD</span>
                </div>
              </div>

              {/* Coupon code enter */}
              <div className="mb-5 space-y-1">
                <label className="block text-[10px] text-neutral-400">Have a Promotional Code?</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="HUBGOLD10 or LUXURYVIP"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    className="flex-1 bg-neutral-900 border border-neutral-850 rounded-lg px-2.5 py-1.5 text-xs font-mono text-white uppercase focus:outline-none focus:border-gold-500"
                  />
                  <button
                    type="button"
                    onClick={handleApplyCoupon}
                    className="py-1 px-3 bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold rounded-lg text-gold-400 transition"
                  >
                    Apply Code
                  </button>
                </div>
                {couponStatus === 'invalid' && (
                  <span className="text-[10px] text-red-400 block mt-0.5">Invalid promotional code coordinates.</span>
                )}
                {couponStatus === 'success' && (
                  <span className="text-[10px] text-green-400 block mt-0.5">Promotional code applied successfully.</span>
                )}
              </div>

              {/* Payment Fields (Stripe integration simulation) */}
              {paymentError && (
                <div className="mb-4 p-2.5 bg-red-950/40 border border-red-500/30 text-red-300 text-xs rounded-lg">
                  {paymentError}
                </div>
              )}

              {paymentSuccess ? (
                <div className="py-6 text-center space-y-2">
                  <div className="inline-flex h-12 w-12 rounded-full bg-green-500/10 border border-green-500/30 text-green-400 items-center justify-center animate-bounce">
                    <CheckCircle size={24} />
                  </div>
                  <h4 className="font-display font-bold text-sm text-white">Payment Authorized!</h4>
                  <p className="text-[11px] text-neutral-400">Subscription coordinates established in ledger.</p>
                </div>
              ) : (
                <form onSubmit={handleCheckoutSubmit} className="space-y-4">
                  <div>
                    <label className="block text-[10px] text-neutral-400 mb-1">Select Gateway Provider</label>
                    <div className="grid grid-cols-3 gap-1.5 text-[11px] text-center font-semibold">
                      <button
                        type="button"
                        onClick={() => {
                          setActiveGateway('stripe');
                          setCardNumber('');
                        }}
                        className={`py-1.5 rounded-lg flex items-center justify-center gap-1 border transition ${
                          activeGateway === 'stripe'
                            ? 'bg-gold-400 text-neutral-950 border-gold-300'
                            : 'bg-neutral-900 text-neutral-400 border-neutral-850 hover:text-white'
                        }`}
                      >
                        <CreditCard size={10} />
                        Stripe
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setActiveGateway('paypal');
                          setCardNumber('');
                        }}
                        className={`py-1.5 rounded-lg flex items-center justify-center gap-1 border transition ${
                          activeGateway === 'paypal'
                            ? 'bg-gold-400 text-neutral-950 border-gold-300'
                            : 'bg-neutral-900 text-neutral-400 border-neutral-850 hover:text-white'
                        }`}
                      >
                        PayPal
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setActiveGateway('whatsapp');
                          setCardNumber('');
                        }}
                        className={`py-1.5 rounded-lg flex items-center justify-center gap-1 border transition ${
                          activeGateway === 'whatsapp'
                            ? 'bg-green-500 text-neutral-950 border-green-400'
                            : 'bg-neutral-900 text-neutral-400 border-neutral-850 hover:text-white'
                        }`}
                      >
                        💬 WhatsApp
                      </button>
                    </div>
                  </div>

                  {activeGateway === 'whatsapp' ? (
                    <div className="p-4 rounded-xl border border-green-500/20 bg-green-950/15 space-y-3">
                      <div className="flex items-center gap-2 text-green-400 font-bold text-xs">
                        <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                        Direct WhatsApp Payment Channel
                      </div>
                      <p className="text-[11px] text-neutral-300 leading-relaxed">
                        To activate your subscription instantly, click below to message our billing coordinator on WhatsApp. Once completed, enter the verification reference ID provided.
                      </p>
                      <a
                        href={`https://wa.me/2349039106418?text=Hello! I would like to subscribe to the creator @${creator.username} on the ${checkoutPlan.title} plan for $${getDiscountedPrice(checkoutPlan.price)}. User Email: ${currentUser?.email || 'Anonymous'}`}
                        target="_blank"
                        rel="noreferrer"
                        className="w-full py-2 bg-green-500 hover:bg-green-600 text-neutral-950 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition active:scale-[0.98] cursor-pointer"
                      >
                        Message WhatsApp: +234 903 910 6418
                      </a>
                      <div className="space-y-1 pt-1">
                        <label className="block text-[10px] text-neutral-400">WhatsApp Payment Reference ID</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. WHATS-489A"
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value)}
                          className="w-full bg-neutral-900 border border-neutral-850 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-green-500"
                        />
                      </div>
                    </div>
                  ) : (
                    <>
                      <div>
                        <label className="block text-[10px] text-neutral-400 mb-1">Credit Card Number</label>
                        <input
                          type="text"
                          required
                          placeholder="4242 4242 4242 4242 (Stripe Demo)"
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value.replace(/\s?/g, '').replace(/(\d{4})/g, '$1 ').trim())}
                          className="w-full bg-neutral-900 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition font-mono"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] text-neutral-400 mb-1">Expiration Date</label>
                          <input
                            type="text"
                            required
                            placeholder="MM/YY"
                            value={cardExpiry}
                            onChange={(e) => setCardExpiry(e.target.value)}
                            className="w-full bg-neutral-900 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition text-center"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-neutral-400 mb-1">CVV Security Code</label>
                          <input
                            type="password"
                            required
                            maxLength={3}
                            placeholder="•••"
                            value={cardCvv}
                            onChange={(e) => setCardCvv(e.target.value)}
                            className="w-full bg-neutral-900 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition text-center font-mono"
                          />
                        </div>
                      </div>
                    </>
                  )}

                  <button
                    type="submit"
                    disabled={isProcessing}
                    className="w-full py-2.5 bg-gradient-to-r from-gold-600 to-gold-400 text-neutral-950 font-display font-bold rounded-xl text-xs transition"
                  >
                    {isProcessing ? 'Processing Transaction Vault...' : `Authorize $${getDiscountedPrice(checkoutPlan.price)}`}
                  </button>
                </form>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Share coordinates Panel */}
      <AnimatePresence>
        {isSharing && (
          <div id="share-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-sm rounded-3xl border border-gold-400/30 bg-neutral-950 p-6 text-white text-center space-y-4"
            >
              <div className="flex justify-between items-center border-b border-neutral-900 pb-2.5">
                <span className="font-display font-bold text-xs text-gold-400 uppercase">Share Profile Channels</span>
                <button onClick={() => setIsSharing(false)} className="text-neutral-400 hover:text-white text-xs">
                  Close
                </button>
              </div>

              {/* QR Code generator mock */}
              <div className="bg-white p-3 rounded-2xl w-40 h-40 mx-auto flex items-center justify-center shadow-lg border border-gold-400/20">
                <svg className="w-full h-full text-neutral-950" viewBox="0 0 100 100">
                  <path fill="currentColor" d="M10,10 h30 v30 h-30 z M20,20 h10 v10 h-10 z M60,10 h30 v30 h-30 z M70,20 h10 v10 h-10 z M10,60 h30 v30 h-30 z M20,70 h10 v10 h-10 z M60,60 h10 v10 h-10 z M80,60 h10 v10 h-10 z M70,70 h10 v10 h-10 z M60,80 h10 v10 h-10 z M80,80 h10 v10 h-10 z" />
                </svg>
              </div>

              <div>
                <h4 className="font-display font-bold text-sm">QR Code Sharing</h4>
                <p className="text-[10px] text-neutral-400 mt-1">Scan to connect to @{creator.username} directly from mobile devices.</p>
              </div>

              {/* Copy links */}
              <div className="flex gap-2">
                <input
                  type="text"
                  readOnly
                  value={`https://creatorhub.com/channels/${creator.username}`}
                  className="flex-1 bg-neutral-900 border border-neutral-850 rounded-lg px-2.5 py-1.5 text-[10px] font-mono text-neutral-400 select-all"
                />
                <button
                  onClick={handleCopyProfileLink}
                  className="p-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-gold-400 hover:text-white transition"
                >
                  {copied ? <Check size={14} /> : <Copy size={14} />}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
