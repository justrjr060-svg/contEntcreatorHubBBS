import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Sparkles,
  UploadCloud,
  FileText,
  DollarSign,
  Eye,
  Users,
  Settings,
  Plus,
  Tv,
  Image as ImageIcon,
  Check,
  X,
  ShieldCheck,
  TrendingUp,
  Briefcase
} from 'lucide-react';
import { User, Creator, ContentItem, Plan } from '../types';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { storage } from '../firebase';

interface CreatorDashboardProps {
  currentUser: User;
  creatorProfile: Creator;
  onUpdateCreatorProfile: (updatedProfile: Creator) => void;
  onAddContent: (content: ContentItem) => void;
  collabApplications: {
    id: string;
    senderName: string;
    senderEmail: string;
    message: string;
    proposedBudget: number;
    status: 'pending' | 'accepted' | 'declined';
  }[];
  onRespondToCollab: (collabId: string, action: 'accepted' | 'declined') => void;
}

export default function CreatorDashboard({
  currentUser,
  creatorProfile,
  onUpdateCreatorProfile,
  onAddContent,
  collabApplications,
  onRespondToCollab
}: CreatorDashboardProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'upload' | 'collabs' | 'settings'>('overview');

  // Content Upload Form state
  const [newPostTitle, setNewPostTitle] = useState('');
  const [newPostDesc, setNewPostDesc] = useState('');
  const [newPostType, setNewPostType] = useState<'video' | 'image' | 'blog'>('image');
  const [newPostMinTier, setNewPostMinTier] = useState<number>(0);
  const [newPostMedia, setNewPostMedia] = useState('');
  const [newPostBody, setNewPostBody] = useState('');
  const [newPostDuration, setNewPostDuration] = useState('');
  const [uploadSuccess, setUploadSuccess] = useState('');

  // Drag and Drop & Upload status state
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const uploadFileToFirebase = (file: File) => {
    if (!file) return;
    setIsUploading(true);
    setUploadProgress(0);

    const storageRef = ref(storage, `channels/${creatorProfile.username}/${Date.now()}_${file.name}`);
    const uploadTask = uploadBytesResumable(storageRef, file);

    uploadTask.on(
      'state_changed',
      (snapshot) => {
        const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
        setUploadProgress(progress);
      },
      (error) => {
        console.error('Upload failed:', error);
        alert(`Media upload failed: ${error.message}`);
        setIsUploading(false);
      },
      async () => {
        try {
          const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);
          setNewPostMedia(downloadUrl);
        } catch (err: any) {
          console.error('Error getting download URL:', err);
          alert(`Failed to retrieve media coordinates: ${err.message}`);
        } finally {
          setIsUploading(false);
        }
      }
    );
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      uploadFileToFirebase(e.target.files[0]);
    }
  };

  const handleFileDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      uploadFileToFirebase(e.dataTransfer.files[0]);
    }
  };

  // Settings Edit form state
  const [editBio, setEditBio] = useState(creatorProfile.bio);
  const [editCategory, setEditCategory] = useState(creatorProfile.category);
  const [editTags, setEditTags] = useState(creatorProfile.tags.join(', '));
  const [editBanner, setEditBanner] = useState(creatorProfile.bannerUrl);
  const [editTwitter, setEditTwitter] = useState(creatorProfile.socialLinks.twitter || '');
  const [editInsta, setEditInsta] = useState(creatorProfile.socialLinks.instagram || '');
  const [settingsSuccess, setSettingsSuccess] = useState('');

  const handleUploadPost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostTitle.trim()) return;

    const defaultImageMap = {
      image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=600',
      video: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&q=80&w=600',
      blog: 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&q=80&w=600'
    };

    const mediaUrl = newPostMedia.trim() || defaultImageMap[newPostType];

    const newItem: ContentItem = {
      id: 'post_new_' + Date.now(),
      creatorId: creatorProfile.id,
      title: newPostTitle,
      description: newPostDesc,
      type: newPostType,
      mediaUrl,
      minTier: newPostMinTier,
      likes: 0,
      comments: [],
      date: new Date().toISOString().split('T')[0],
      duration: newPostType === 'video' ? (newPostDuration || '12:00') : undefined,
      body: newPostType === 'blog' ? newPostBody : undefined
    };

    onAddContent(newItem);

    // Reset Form
    setNewPostTitle('');
    setNewPostDesc('');
    setNewPostType('image');
    setNewPostMinTier(0);
    setNewPostMedia('');
    setNewPostBody('');
    setNewPostDuration('');
    setUploadSuccess('Premium content successfully published to your subscribers!');
    setTimeout(() => setUploadSuccess(''), 3000);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: Creator = {
      ...creatorProfile,
      bio: editBio,
      category: editCategory,
      bannerUrl: editBanner,
      tags: editTags.split(',').map((t) => t.trim()).filter(Boolean),
      socialLinks: {
        twitter: editTwitter,
        instagram: editInsta
      }
    };
    onUpdateCreatorProfile(updated);
    setSettingsSuccess('Creator profile specifications updated successfully!');
    setTimeout(() => setSettingsSuccess(''), 3000);
  };

  return (
    <div id="creator-dashboard-container" className="space-y-6">
      {/* Profile Header banner */}
      <div className="relative h-44 rounded-3xl overflow-hidden border border-neutral-800">
        <img
          src={creatorProfile.bannerUrl}
          alt="Creator banner"
          className="w-full h-full object-cover brightness-50"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/40 to-transparent" />
        <div className="absolute bottom-5 left-5 right-5 flex flex-col md:flex-row md:items-end justify-between gap-3">
          <div className="flex items-center gap-3">
            <img
              src={creatorProfile.avatarUrl}
              alt={creatorProfile.name}
              className="w-16 h-16 rounded-full border-2 border-gold-400 object-cover"
            />
            <div>
              <h3 className="font-display font-bold text-lg text-white">{creatorProfile.name}</h3>
              <span className="text-xs text-gold-400">@{creatorProfile.username} • {creatorProfile.category}</span>
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="px-3 py-1 bg-gold-500/10 border border-gold-400/20 text-gold-400 rounded-full font-mono">
              Rating: ★ {creatorProfile.rating}
            </span>
          </div>
        </div>
      </div>

      {/* Selector Tabs */}
      <div className="flex border-b border-neutral-900 pb-1 text-xs">
        <button
          onClick={() => setActiveTab('overview')}
          className={`pb-2 px-4 font-semibold transition border-b-2 ${
            activeTab === 'overview' ? 'text-gold-400 border-gold-400' : 'text-neutral-400 hover:text-white border-transparent'
          }`}
        >
          📈 Studio Metrics
        </button>
        <button
          onClick={() => setActiveTab('upload')}
          className={`pb-2 px-4 font-semibold transition border-b-2 ${
            activeTab === 'upload' ? 'text-gold-400 border-gold-400' : 'text-neutral-400 hover:text-white border-transparent'
          }`}
        >
          📤 Publish Content
        </button>
        <button
          onClick={() => setActiveTab('collabs')}
          className={`pb-2 px-4 font-semibold transition border-b-2 ${
            activeTab === 'collabs' ? 'text-gold-400 border-gold-400' : 'text-neutral-400 hover:text-white border-transparent'
          }`}
        >
          💼 Brand Opportunities ({collabApplications.length})
        </button>
        <button
          onClick={() => setActiveTab('settings')}
          className={`pb-2 px-4 font-semibold transition border-b-2 ${
            activeTab === 'settings' ? 'text-gold-400 border-gold-400' : 'text-neutral-400 hover:text-white border-transparent'
          }`}
        >
          ⚙️ Customize Channel
        </button>
      </div>

      {/* Tab content 1: Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Quick Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-1">
              <span className="text-xs text-neutral-400">Total Revenue Earned</span>
              <h4 className="text-2xl font-bold font-display text-white">${creatorProfile.revenue.toLocaleString()}</h4>
              <p className="text-[10px] text-green-400 flex items-center gap-1">
                <TrendingUp size={12} />
                <span>+8.4% current month cycle</span>
              </p>
            </div>
            <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-1">
              <span className="text-xs text-neutral-400">Subscribers</span>
              <h4 className="text-2xl font-bold font-display text-white">{creatorProfile.subscriberCount}</h4>
              <p className="text-[10px] text-gold-400">Active Tier 2 & 3: 42%</p>
            </div>
            <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-1">
              <span className="text-xs text-neutral-400">Content Views</span>
              <h4 className="text-2xl font-bold font-display text-white">{creatorProfile.viewsCount.toLocaleString()}</h4>
              <p className="text-[10px] text-neutral-400">Avg. Engagement Rate: 18.2%</p>
            </div>
          </div>

          {/* Published Content list */}
          <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4">
            <h4 className="font-display font-semibold text-xs tracking-wider text-neutral-300 uppercase">My Publications</h4>
            <div className="space-y-3">
              {creatorProfile.posts.map((post) => (
                <div key={post.id} className="p-3 bg-neutral-950 border border-neutral-850 rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={post.mediaUrl}
                      alt={post.title}
                      className="w-12 h-12 rounded-lg object-cover border border-neutral-850"
                    />
                    <div>
                      <span className="font-bold text-white text-xs">{post.title}</span>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[9px] font-mono bg-neutral-900 text-neutral-400 px-1.5 py-0.5 rounded border border-neutral-800">
                          {post.type.toUpperCase()}
                        </span>
                        <span className="text-[10px] text-gold-400 font-medium">
                          {post.minTier === 0 ? '🔓 Public' : `🔒 Tier ${post.minTier}+`}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 text-[10px] text-neutral-400 font-mono">
                    <span>❤️ {post.likes} Likes</span>
                    <span>💬 {post.comments.length} Comments</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab content 2: Upload Post */}
      {activeTab === 'upload' && (
        <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4">
          <h4 className="font-display font-semibold text-xs tracking-wider text-neutral-300 uppercase">Publish Premium Content</h4>

          {uploadSuccess && (
            <div className="p-3 bg-green-950/20 border border-green-500/20 text-green-300 text-xs rounded-xl flex items-center gap-2">
              <ShieldCheck size={16} className="text-green-400 shrink-0" />
              <span>{uploadSuccess}</span>
            </div>
          )}

          <form onSubmit={handleUploadPost} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-medium text-neutral-400 mb-1">Post Title</label>
                <input
                  type="text"
                  required
                  placeholder="Private Behind-the-scenes Vlog from Milan runway"
                  value={newPostTitle}
                  onChange={(e) => setNewPostTitle(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-neutral-400 mb-1">Format Type</label>
                <select
                  value={newPostType}
                  onChange={(e) => setNewPostType(e.target.value as any)}
                  className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition"
                >
                  <option value="image">📸 Premium Image</option>
                  <option value="video">🎥 VIP Video</option>
                  <option value="blog">✍️ Editorial/Blog</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-neutral-400 mb-1">Summary Description</label>
              <input
                type="text"
                placeholder="A brief snippet of what lies in this publication..."
                value={newPostDesc}
                onChange={(e) => setNewPostDesc(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-neutral-400 mb-1">Gated Protection Tier</label>
                <select
                  value={newPostMinTier}
                  onChange={(e) => setNewPostMinTier(parseInt(e.target.value))}
                  className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition"
                >
                  <option value={0}>🔓 Everyone (Public)</option>
                  <option value={1}>🥉 Bronze Plan & Above</option>
                  <option value={2}>🥈 Silver Plan & Above</option>
                  <option value={3}>👑 Gold VIP Members Only</option>
                </select>
              </div>

              <div className="sm:col-span-2 space-y-2">
                <label className="block text-[11px] font-medium text-neutral-400">Media Asset (Upload with Storage or Enter URL)</label>
                
                {/* Drag and Drop Zone */}
                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDragging(true);
                  }}
                  onDragLeave={() => setIsDragging(false)}
                  onDrop={handleFileDrop}
                  className={`border border-dashed rounded-xl p-3 text-center cursor-pointer transition relative overflow-hidden ${
                    isDragging
                      ? 'border-gold-400 bg-gold-400/5'
                      : 'border-neutral-800 bg-neutral-950 hover:border-gold-400/30'
                  }`}
                  onClick={() => document.getElementById('file-upload-input')?.click()}
                >
                  <input
                    id="file-upload-input"
                    type="file"
                    accept="image/*,video/*"
                    className="hidden"
                    onChange={handleFileSelect}
                  />
                  
                  {isUploading ? (
                    <div className="space-y-2 py-1">
                      <div className="text-[11px] text-gold-400 font-semibold animate-pulse">Uploading to Firebase... {uploadProgress}%</div>
                      <div className="w-full bg-neutral-900 rounded-full h-1 overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-gold-600 to-gold-400 h-1 rounded-full transition-all duration-300"
                          style={{ width: `${uploadProgress}%` }}
                        />
                      </div>
                    </div>
                  ) : newPostMedia ? (
                    <div className="flex items-center justify-between gap-2 text-left">
                      <div className="truncate">
                        <span className="block text-[9px] text-neutral-500">Asset Linked:</span>
                        <span className="text-[11px] text-gold-400 truncate font-mono block max-w-[280px]">{newPostMedia}</span>
                      </div>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setNewPostMedia('');
                        }}
                        className="p-1 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-red-400"
                        title="Clear asset"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-1 py-1">
                      <div className="flex justify-center text-neutral-500">
                        <UploadCloud size={18} className="text-neutral-500 hover:text-gold-400 transition-colors" />
                      </div>
                      <p className="text-[11px] text-neutral-300 font-medium">
                        Drag & Drop file or <span className="text-gold-400 hover:underline">Browse</span>
                      </p>
                      <p className="text-[9px] text-neutral-500">Auto-saves to Firebase Storage (Images/Videos)</p>
                    </div>
                  )}
                </div>

                <input
                  type="text"
                  placeholder="Or paste an external media URL directly..."
                  value={newPostMedia}
                  onChange={(e) => setNewPostMedia(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-1.5 px-3 text-[10px] text-neutral-300 focus:outline-none focus:border-gold-500 transition"
                />
              </div>
            </div>

            {newPostType === 'video' && (
              <div>
                <label className="block text-[11px] font-medium text-neutral-400 mb-1">Video Duration (e.g., 14:20)</label>
                <input
                  type="text"
                  placeholder="14:20"
                  value={newPostDuration}
                  onChange={(e) => setNewPostDuration(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition"
                />
              </div>
            )}

            {newPostType === 'blog' && (
              <div>
                <label className="block text-[11px] font-medium text-neutral-400 mb-1">Editorial Body Content</label>
                <textarea
                  rows={6}
                  placeholder="Write your long-form article details here..."
                  value={newPostBody}
                  onChange={(e) => setNewPostBody(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2.5 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition resize-none"
                />
              </div>
            )}

            <button
              type="submit"
              className="px-5 py-2.5 bg-gradient-to-r from-gold-600 to-gold-400 text-neutral-950 font-display font-bold rounded-xl text-xs flex items-center gap-1.5 transition active:scale-98"
            >
              <UploadCloud size={16} />
              Publish to Feed
            </button>
          </form>
        </div>
      )}

      {/* Tab content 3: Brand Collaborations */}
      {activeTab === 'collabs' && (
        <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4">
          <h4 className="font-display font-semibold text-xs tracking-wider text-neutral-300 uppercase">Collaboration Proposals</h4>
          {collabApplications.length === 0 ? (
            <p className="text-neutral-400 text-xs py-4">No incoming brand proposals at present.</p>
          ) : (
            <div className="space-y-4">
              {collabApplications.map((app) => (
                <div
                  key={app.id}
                  className={`p-4 rounded-xl border transition ${
                    app.status === 'accepted'
                      ? 'bg-green-950/20 border-green-500/20'
                      : app.status === 'declined'
                      ? 'bg-red-950/20 border-red-500/20'
                      : 'bg-neutral-950 border-neutral-850'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <Briefcase size={14} className="text-gold-400" />
                        <h5 className="font-display font-bold text-sm text-white">{app.senderName}</h5>
                        <span className="text-[10px] text-neutral-500 font-mono">({app.senderEmail})</span>
                        <span className={`px-2 py-0.5 rounded text-[9px] font-mono uppercase ${
                          app.status === 'pending' ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20' :
                          app.status === 'accepted' ? 'bg-green-500/10 text-green-400 border border-green-500/20' :
                          'bg-red-500/10 text-red-400 border border-red-500/20'
                        }`}>
                          {app.status}
                        </span>
                      </div>
                      <p className="text-xs text-neutral-300 mt-2 leading-relaxed">"{app.message}"</p>
                      <div className="mt-2 text-xs font-semibold text-gold-400">
                        Proposed Budget Amount: ${app.proposedBudget.toLocaleString()}
                      </div>
                    </div>

                    {app.status === 'pending' && (
                      <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                        <button
                          onClick={() => onRespondToCollab(app.id, 'accepted')}
                          className="flex items-center gap-1 py-1.5 px-3 bg-gold-500 hover:bg-gold-600 text-neutral-950 font-bold rounded-lg text-xs transition"
                        >
                          <Check size={12} />
                          Accept Offer
                        </button>
                        <button
                          onClick={() => onRespondToCollab(app.id, 'declined')}
                          className="flex items-center gap-1 py-1.5 px-3 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg text-xs transition"
                        >
                          <X size={12} />
                          Decline
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab content 4: Channel Settings */}
      {activeTab === 'settings' && (
        <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4">
          <h4 className="font-display font-semibold text-xs tracking-wider text-neutral-300 uppercase">Refine channel specs</h4>

          {settingsSuccess && (
            <div className="p-3 bg-green-950/20 border border-green-500/20 text-green-300 text-xs rounded-xl flex items-center gap-2">
              <ShieldCheck size={16} className="text-green-400 shrink-0" />
              <span>{settingsSuccess}</span>
            </div>
          )}

          <form onSubmit={handleSaveSettings} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-neutral-400 mb-1">Niche Category</label>
                <input
                  type="text"
                  required
                  value={editCategory}
                  onChange={(e) => setEditCategory(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-neutral-400 mb-1">Tags (comma-separated)</label>
                <input
                  type="text"
                  required
                  value={editTags}
                  onChange={(e) => setEditTags(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition font-mono text-[11px]"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-neutral-400 mb-1">Channel bio description</label>
              <textarea
                rows={3}
                required
                value={editBio}
                onChange={(e) => setEditBio(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition resize-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-neutral-400 mb-1">Banner asset URL</label>
              <input
                type="text"
                required
                value={editBanner}
                onChange={(e) => setEditBanner(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-neutral-400 mb-1">Twitter coordinates</label>
                <input
                  type="text"
                  value={editTwitter}
                  onChange={(e) => setEditTwitter(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-neutral-400 mb-1">Instagram coordinates</label>
                <input
                  type="text"
                  value={editInsta}
                  onChange={(e) => setEditInsta(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-850 rounded-xl py-2 px-3 text-xs text-white focus:outline-none focus:border-gold-500 transition"
                />
              </div>
            </div>

            <button
              type="submit"
              className="py-2 px-5 bg-gradient-to-r from-gold-600 to-gold-400 text-neutral-950 font-bold rounded-xl text-xs transition"
            >
              Update Channel Specifications
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
