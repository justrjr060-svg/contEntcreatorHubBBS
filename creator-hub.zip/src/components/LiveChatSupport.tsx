import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, X, Send, ShieldCheck, Headphones, HelpCircle } from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'support';
  text: string;
  time: string;
}

export default function LiveChatSupport() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm1',
      sender: 'support',
      text: 'Greetings. I am Gideon, your Creator Hub VIP Support Liaison. How may I refine your membership experience today?',
      time: 'Just now'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [activeTab, setActiveTab] = useState<'chat' | 'faqs'>('chat');

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isTyping]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const userMsg: ChatMessage = {
      id: 'user_' + Date.now(),
      sender: 'user',
      text: inputText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    const userQuery = inputText.toLowerCase();
    setInputText('');
    setIsTyping(true);

    // Dynamic responses based on keywords
    setTimeout(() => {
      let responseText = "Thank you for sharing your coordinates. An luxury concierge specialist will review your inquiry shortly. Would you like to leave your email so we can reach you outside the terminal?";

      if (userQuery.includes('plan') || userQuery.includes('membership') || userQuery.includes('subscribe')) {
        responseText = "Our membership levels range from Bronze (basic exclusive photos) to Gold VIP (which triggers personal 1-on-1 monthly consultations). Subscribing is handled immediately via our secure credit card processor integration. Payments are fully recurring and encrypted.";
      } else if (userQuery.includes('creator') || userQuery.includes('apply') || userQuery.includes('collaboration')) {
        responseText = "If you wish to apply as a platform Creator, click 'Apply for Collaboration' in the navigation menu. Complete the application with your portfolio link. Platform admins audit applications within 24 hours.";
      } else if (userQuery.includes('stripe') || userQuery.includes('payment') || userQuery.includes('paypal')) {
        responseText = "All payments are processed through industry leaders Stripe and PayPal using high-grade end-to-end encryption. No financial credentials are ever written to plain storage. Subscriptions renew automatically.";
      } else if (userQuery.includes('coupon') || userQuery.includes('discount')) {
        responseText = "You may apply platform coupons (such as 'HUBGOLD10' for 10% off or 'LUXURYVIP' for $5.00 off) during your checkout checkout modal. Check your Admin announcements for temporary coupon releases!";
      } else if (userQuery.includes('admin') || userQuery.includes('ban') || userQuery.includes('delete')) {
        responseText = "Administrators wield full sovereignty over community moderation, user accounts, and content curation. If you require content deletion or reporting, use the 'Report' button on any content file.";
      }

      setMessages((prev) => [
        ...prev,
        {
          id: 'support_' + Date.now(),
          sender: 'support',
          text: responseText,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
      setIsTyping(false);
    }, 1500);
  };

  const FAQS_LIST = [
    {
      q: 'How do subscriptions renew?',
      a: 'All plans auto-renew monthly. You can easily manage or cancel active subscriptions inside your Subscriber Profile page anytime with instant effect.'
    },
    {
      q: 'How are Creator earnings processed?',
      a: 'Creator payouts are computed instantly and dispatched on the 1st of every calendar month through connected Stripe or PayPal accounts.'
    },
    {
      q: 'What is the Collaboration Application?',
      a: 'Supporters can fill out standard request forms directly to Creators. If a creator is looking for specialized services, you can lock down an official deal.'
    },
    {
      q: 'Is there a referral program?',
      a: 'Absolutely! Inside your subscriber profile dashboard, you can trigger your custom invitation coordinates. Each successful referral awards a permanent 10% credit.'
    }
  ];

  return (
    <div className="fixed bottom-6 right-6 z-40">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 30 }}
            className="w-80 sm:w-96 h-[480px] rounded-2xl border border-gold-400/30 bg-neutral-950 shadow-[0_15px_50px_rgba(0,0,0,0.6)] flex flex-col overflow-hidden text-white"
          >
            {/* Header */}
            <div className="p-4 bg-gradient-to-r from-neutral-900 to-neutral-950 border-b border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-gold-500/10 border border-gold-400/20 text-gold-400">
                  <Headphones size={18} />
                </div>
                <div>
                  <h4 className="font-display font-bold text-xs tracking-wide">CREATOR HUB SUPPORT</h4>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-green-400 animate-pulse" />
                    <span className="text-[10px] text-neutral-400 font-medium">Concierge Active</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
              >
                <X size={16} />
              </button>
            </div>

            {/* Toggle Tabs */}
            <div className="flex border-b border-neutral-900 text-xs text-center bg-neutral-900/40">
              <button
                onClick={() => setActiveTab('chat')}
                className={`flex-1 py-2 font-medium transition ${
                  activeTab === 'chat' ? 'text-gold-400 border-b-2 border-gold-400 bg-neutral-950/20' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Live Concierge
              </button>
              <button
                onClick={() => setActiveTab('faqs')}
                className={`flex-1 py-2 font-medium transition ${
                  activeTab === 'faqs' ? 'text-gold-400 border-b-2 border-gold-400 bg-neutral-950/20' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Instant FAQs
              </button>
            </div>

            {/* Content Body */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-neutral-950">
              {activeTab === 'chat' ? (
                <>
                  <div className="text-center text-[10px] text-neutral-500 py-1">
                    🔒 Messages are protected with AES-256 end-to-end encryption.
                  </div>
                  {messages.map((m) => (
                    <div key={m.id} className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div
                        className={`max-w-[85%] rounded-2xl px-3 py-2 text-xs ${
                          m.sender === 'user'
                            ? 'bg-gold-500 text-neutral-950 font-medium rounded-tr-none'
                            : 'bg-neutral-900 border border-neutral-800 text-neutral-200 rounded-tl-none'
                        }`}
                      >
                        <p>{m.text}</p>
                        <span className="block text-[8px] mt-1 text-right opacity-60 font-mono">
                          {m.time}
                        </span>
                      </div>
                    </div>
                  ))}

                  {isTyping && (
                    <div className="flex justify-start">
                      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl rounded-tl-none px-3 py-2 text-xs text-neutral-400 flex items-center gap-1.5">
                        <span className="h-1.5 w-1.5 bg-gold-400 rounded-full animate-bounce" />
                        <span className="h-1.5 w-1.5 bg-gold-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                        <span className="h-1.5 w-1.5 bg-gold-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </>
              ) : (
                <div className="space-y-3.5 pt-1">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-gold-400">
                    <HelpCircle size={14} />
                    <span>Frequently Answered Inquiries</span>
                  </div>
                  {FAQS_LIST.map((faq, i) => (
                    <div key={i} className="p-3 rounded-xl bg-neutral-900/60 border border-neutral-900 space-y-1">
                      <h5 className="text-xs font-bold text-white font-display">{faq.q}</h5>
                      <p className="text-[11px] text-neutral-400 leading-relaxed">{faq.a}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Chat Input Footer */}
            {activeTab === 'chat' && (
              <form onSubmit={handleSendMessage} className="p-3 border-t border-neutral-900 bg-neutral-900/30 flex gap-2">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="Ask about plans, creators, coupon..."
                  className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-gold-500 transition"
                />
                <button
                  type="submit"
                  className="p-2 rounded-xl bg-gradient-to-r from-gold-600 to-gold-400 text-neutral-950 hover:opacity-90 active:scale-95 transition"
                >
                  <Send size={14} />
                </button>
              </form>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Toggle Button */}
      <motion.button
        id="chat-support-toggle"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="h-14 w-14 rounded-full bg-gradient-to-r from-gold-600 to-gold-400 text-neutral-950 flex items-center justify-center shadow-lg shadow-gold-500/20 border border-gold-300 pointer-events-auto"
      >
        <MessageSquare size={22} className="text-neutral-950" />
      </motion.button>
    </div>
  );
}
