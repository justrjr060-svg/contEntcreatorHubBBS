import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Mail, Lock, ShieldCheck, User as UserIcon, CheckCircle2, Loader2 } from 'lucide-react';
import { User } from '../types';
import { auth, db } from '../firebase';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (user: User) => void;
}

export default function AuthModal({ isOpen, onClose, onAuthSuccess }: AuthModalProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [forgotPassword, setForgotPassword] = useState(false);
  const [step, setStep] = useState<'form' | 'verification' | 'twoFactor'>('form');

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [isCreator, setIsCreator] = useState(false);

  // Verification & 2FA codes
  const [verificationCode, setVerificationCode] = useState('');
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleReset = () => {
    setIsLogin(true);
    setForgotPassword(false);
    setStep('form');
    setError('');
    setSuccessMsg('');
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);

    try {
      if (forgotPassword) {
        if (!email) {
          setError('Please enter your email address.');
          setIsSubmitting(false);
          return;
        }
        await sendPasswordResetEmail(auth, email);
        setSuccessMsg(`A password reset link has been dispatched to ${email}.`);
        setTimeout(() => {
          setForgotPassword(false);
          setSuccessMsg('');
        }, 3500);
        setIsSubmitting(false);
        return;
      }

      if (isLogin) {
        if (!email || !password) {
          setError('Please fill in all credentials.');
          setIsSubmitting(false);
          return;
        }

        // Demo accounts
        const isDemoAdmin = email === 'admin@creatorhub.com';
        const isDemoCreator = email === 'elena@creatorhub.com';

        try {
          await signInWithEmailAndPassword(auth, email, password);
        } catch (signInErr: any) {
          // If demo accounts do not exist in Firebase Auth, auto-create them
          if ((isDemoAdmin || isDemoCreator) && (signInErr.code === 'auth/user-not-found' || signInErr.code === 'auth/invalid-credential')) {
            try {
              await createUserWithEmailAndPassword(auth, email, password);
            } catch (signUpErr: any) {
              console.error('Failed to auto-create demo user:', signUpErr);
              throw signInErr;
            }
          } else {
            throw signInErr;
          }
        }

        if (isDemoAdmin || isDemoCreator) {
          // Trigger 2FA mock for admin or creator
          setStep('twoFactor');
        } else {
          // Normal user login, skip 2FA, fetch/create profile in Firestore
          const uid = auth.currentUser?.uid;
          if (uid) {
            const userDocRef = doc(db, 'users', uid);
            const userDoc = await getDoc(userDocRef);
            if (userDoc.exists()) {
              completeLogin(userDoc.data() as User);
            } else {
              const defaultProfile: User = {
                id: uid,
                email,
                username: email.split('@')[0],
                name: email.split('@')[0].toUpperCase(),
                avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${email}`,
                role: 'member',
                isVerified: true,
                is2FAEnabled: false,
                activeSubscriptions: {},
                favorites: [],
                status: 'active'
              };
              await setDoc(userDocRef, defaultProfile);
              completeLogin(defaultProfile);
            }
          }
        }
      } else {
        // Register
        if (!email || !password || !name || !username) {
          setError('Please fill in all requested fields.');
          setIsSubmitting(false);
          return;
        }

        // Create user in Firebase Auth
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const uid = userCredential.user.uid;

        // Save profile in Firestore
        const newUserProfile: User = {
          id: uid,
          email,
          username,
          name,
          avatarUrl: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
          role: isCreator ? 'creator' : 'member',
          isVerified: true,
          is2FAEnabled: false,
          activeSubscriptions: {},
          favorites: [],
          status: 'active'
        };

        await setDoc(doc(db, 'users', uid), newUserProfile);

        // Go to premium simulated verification screen
        setStep('verification');
      }
    } catch (err: any) {
      console.error(err);
      let friendlyMessage = err.message || 'Authentication coordinates error.';
      if (err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        friendlyMessage = 'Invalid password or verification coordinates.';
      } else if (err.code === 'auth/user-not-found') {
        friendlyMessage = 'No account associated with this email address exists.';
      } else if (err.code === 'auth/email-already-in-use') {
        friendlyMessage = 'This email address is already registered on Creator Hub.';
      } else if (err.code === 'auth/weak-password') {
        friendlyMessage = 'The selected password is too weak. Minimum 6 characters required.';
      }
      setError(friendlyMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleVerifyCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (verificationCode !== '7890') {
      setError('Invalid verification code. Use demo code "7890"');
      return;
    }

    const uid = auth.currentUser?.uid;
    if (uid) {
      setIsSubmitting(true);
      try {
        const userDoc = await getDoc(doc(db, 'users', uid));
        if (userDoc.exists()) {
          completeLogin(userDoc.data() as User);
        } else {
          const fallbackProfile: User = {
            id: uid,
            email,
            username,
            name,
            avatarUrl: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
            role: isCreator ? 'creator' : 'member',
            isVerified: true,
            is2FAEnabled: false,
            activeSubscriptions: {},
            favorites: [],
            status: 'active'
          };
          await setDoc(doc(db, 'users', uid), fallbackProfile);
          completeLogin(fallbackProfile);
        }
      } catch (err: any) {
        setError(`Failed to retrieve profile: ${err.message}`);
      } finally {
        setIsSubmitting(false);
      }
    } else {
      setError('No session active.');
    }
  };

  const handleVerify2FA = async (e: React.FormEvent) => {
    e.preventDefault();
    if (twoFactorCode !== '123456') {
      setError('Invalid 2FA Authenticator code. Use demo code "123456"');
      return;
    }

    const uid = auth.currentUser?.uid;
    if (uid) {
      setIsSubmitting(true);
      try {
        if (email === 'admin@creatorhub.com') {
          const adminProfile: User = {
            id: uid,
            email: 'admin@creatorhub.com',
            username: 'crown_admin',
            name: 'Seraphina Gold',
            avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=200',
            bio: 'Creator Hub Platform Administrator.',
            role: 'admin',
            isVerified: true,
            is2FAEnabled: true,
            activeSubscriptions: {},
            favorites: [],
            status: 'active'
          };
          await setDoc(doc(db, 'users', uid), adminProfile);
          completeLogin(adminProfile);
        } else if (email === 'elena@creatorhub.com') {
          const creatorProfile: User = {
            id: uid,
            email: 'elena@creatorhub.com',
            username: 'elenasterling',
            name: 'Elena Sterling',
            avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
            bio: 'High Fashion & Luxury Lifestyle Content Creator.',
            role: 'creator',
            isVerified: true,
            is2FAEnabled: true,
            activeSubscriptions: {},
            favorites: [],
            status: 'active'
          };
          await setDoc(doc(db, 'users', uid), creatorProfile);
          completeLogin(creatorProfile);
        } else {
          const userDoc = await getDoc(doc(db, 'users', uid));
          if (userDoc.exists()) {
            completeLogin(userDoc.data() as User);
          } else {
            setError('User configuration missing.');
          }
        }
      } catch (err: any) {
        setError(`Failed to retrieve secure configurations: ${err.message}`);
      } finally {
        setIsSubmitting(false);
      }
    } else {
      setError('No session active.');
    }
  };

  const completeLogin = (user: User) => {
    if (rememberMe) {
      localStorage.setItem('creatorhub_user', JSON.stringify(user));
    }
    onAuthSuccess(user);
    handleReset();
    onClose();
  };

  const autoFillAdmin = () => {
    setEmail('admin@creatorhub.com');
    setPassword('admin1234');
    setIsLogin(true);
    setForgotPassword(false);
  };

  const autoFillCreator = () => {
    setEmail('elena@creatorhub.com');
    setPassword('creator1234');
    setIsLogin(true);
    setForgotPassword(false);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div id="auth-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Glass Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-md"
          />

          {/* Modal Container */}
          <motion.div
            id="auth-modal-content"
            initial={{ scale: 0.95, y: 15, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.95, y: 15, opacity: 0 }}
            className="relative w-full max-w-md overflow-hidden rounded-3xl border border-gold-400/30 bg-neutral-950 p-8 shadow-[0_0_50px_rgba(212,170,17,0.15)] text-white"
          >
            {/* Glow design element */}
            <div className="absolute -top-24 -left-24 h-48 w-48 rounded-full bg-gold-500/10 blur-3xl pointer-events-none" />
            <div className="absolute -bottom-24 -right-24 h-48 w-48 rounded-full bg-gold-500/10 blur-3xl pointer-events-none" />

            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <div className="h-2.5 w-2.5 rounded-full bg-gold-400 animate-pulse" />
                <span className="font-display font-semibold tracking-wider text-sm text-gold-400 uppercase">
                  {forgotPassword ? 'Reset Access' : step === 'verification' ? 'Verification' : step === 'twoFactor' ? 'Secure Login' : isLogin ? 'Access Hub' : 'Join Elite'}
                </span>
              </div>
              <button
                id="close-auth-modal"
                onClick={onClose}
                className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-850 transition"
              >
                <X size={20} />
              </button>
            </div>

            {/* Quick Demo Credentials */}
            {step === 'form' && !forgotPassword && (
              <div className="mb-6 p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-neutral-400">
                <span className="font-semibold text-gold-400 block mb-1">💡 Sandbox Credentials:</span>
                <div className="flex flex-wrap gap-2 mt-1">
                  <button
                    onClick={autoFillAdmin}
                    className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 hover:text-gold-300 rounded transition text-left"
                  >
                    👑 Admin Demo
                  </button>
                  <button
                    onClick={autoFillCreator}
                    className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 hover:text-gold-300 rounded transition text-left"
                  >
                    ✨ Creator Demo
                  </button>
                </div>
              </div>
            )}

            {/* Title */}
            <div className="mb-6 text-center">
              <h2 className="font-display text-2xl font-bold tracking-tight">
                {forgotPassword ? (
                  'Forgot Credentials?'
                ) : step === 'verification' ? (
                  'Confirm Your Email'
                ) : step === 'twoFactor' ? (
                  'Two-Factor Authentication'
                ) : isLogin ? (
                  <>Welcome Back to <span className="gold-gradient-text">Creator Hub</span></>
                ) : (
                  <>Unlock Exclusive <span className="gold-gradient-text">Creator Realms</span></>
                )}
              </h2>
              <p className="text-neutral-400 text-xs mt-1.5">
                {forgotPassword
                  ? 'We will transmit coordinates to recover your premium access.'
                  : step === 'verification'
                  ? 'We dispatched a secret code to secure your connection coordinates.'
                  : step === 'twoFactor'
                  ? 'Please check your standard authenticator tool configuration.'
                  : isLogin
                  ? 'Indulge in premium publications, private chats, and tiers.'
                  : 'Establish your account and subscribe to elite creative designers.'}
              </p>
            </div>

            {/* Error & Success Messages */}
            {error && (
              <div className="mb-4 p-3 rounded-xl bg-red-950/40 border border-red-500/30 text-red-200 text-xs">
                {error}
              </div>
            )}
            {successMsg && (
              <div className="mb-4 p-3 rounded-xl bg-green-950/40 border border-green-500/30 text-green-200 text-xs flex items-center gap-2">
                <CheckCircle2 size={16} className="text-green-400 shrink-0" />
                <span>{successMsg}</span>
              </div>
            )}

            {/* Step 1: Login / Sign Up Form */}
            {step === 'form' && (
              <form onSubmit={handleAuthSubmit} className="space-y-4">
                {/* Name & Username for Registration */}
                {!isLogin && !forgotPassword && (
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-medium text-neutral-400 mb-1">Your Name</label>
                      <div className="relative">
                        <UserIcon className="absolute left-3 top-3 text-neutral-500" size={16} />
                        <input
                          type="text"
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="Julian Vance"
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl py-2.5 pl-9 pr-4 text-xs text-white focus:outline-none focus:border-gold-500 transition"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-neutral-400 mb-1">Username</label>
                      <div className="relative">
                        <span className="absolute left-3 top-2.5 text-neutral-500 text-xs">@</span>
                        <input
                          type="text"
                          required
                          value={username}
                          onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/\s+/g, ''))}
                          placeholder="vance"
                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl py-2.5 pl-7 pr-4 text-xs text-white focus:outline-none focus:border-gold-500 transition"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Email */}
                <div>
                  <label className="block text-[11px] font-medium text-neutral-400 mb-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 text-neutral-500" size={16} />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="supporter@creatorhub.com"
                      className="w-full bg-neutral-900 border border-neutral-800 rounded-xl py-2.5 pl-9 pr-4 text-xs text-white focus:outline-none focus:border-gold-500 transition"
                    />
                  </div>
                </div>

                {/* Password (if not forgot password) */}
                {!forgotPassword && (
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="block text-[11px] font-medium text-neutral-400">Password</label>
                      {isLogin && (
                        <button
                          type="button"
                          onClick={() => setForgotPassword(true)}
                          className="text-[10px] text-gold-400 hover:underline"
                        >
                          Forgot?
                        </button>
                      )}
                    </div>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 text-neutral-500" size={16} />
                      <input
                        type="password"
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••••••"
                        className="w-full bg-neutral-900 border border-neutral-800 rounded-xl py-2.5 pl-9 pr-4 text-xs text-white focus:outline-none focus:border-gold-500 transition"
                      />
                    </div>
                  </div>
                )}

                {/* Account Type Option for Registration */}
                {!isLogin && !forgotPassword && (
                  <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-xl flex items-center justify-between">
                    <div>
                      <span className="block text-xs font-semibold text-white">Apply as a Creator?</span>
                      <span className="block text-[10px] text-neutral-400">Upload portfolios and subscribe supporters.</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={isCreator}
                      onChange={(e) => setIsCreator(e.target.checked)}
                      className="h-4 w-4 accent-gold-500 border-neutral-800 rounded focus:ring-0 cursor-pointer"
                    />
                  </div>
                )}

                {/* Session remember me option */}
                {!forgotPassword && (
                  <div className="flex items-center justify-between py-1">
                    <label className="flex items-center gap-2 text-xs text-neutral-400 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={rememberMe}
                        onChange={(e) => setRememberMe(e.target.checked)}
                        className="h-3.5 w-3.5 rounded border-neutral-800 bg-neutral-900 accent-gold-500 cursor-pointer"
                      />
                      Remember my device credentials
                    </label>
                  </div>
                )}

                {/* Submit button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-gold-600 to-gold-400 text-neutral-950 font-display font-bold py-2.5 rounded-xl text-xs shadow-md shadow-gold-500/10 hover:shadow-gold-500/20 active:scale-[0.98] transition duration-200 disabled:opacity-50 flex items-center justify-center gap-1"
                >
                  {isSubmitting && <Loader2 size={14} className="animate-spin" />}
                  {forgotPassword ? 'Send Recovery Coordinates' : isLogin ? 'Access Platform' : 'Generate Premium Account'}
                </button>
              </form>
            )}

            {/* Step 2: Email Verification Simulation */}
            {step === 'verification' && (
              <form onSubmit={handleVerifyCode} className="space-y-4">
                <div className="p-3 rounded-xl bg-gold-500/10 border border-gold-400/20 text-xs text-gold-300 flex items-center gap-2 mb-2">
                  <ShieldCheck size={16} className="shrink-0" />
                  <span>Use Verification Sandbox Bypass code: <strong className="font-mono text-white text-sm ml-1">7890</strong></span>
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-neutral-400 mb-1">Enter Verification Code</label>
                  <input
                    type="text"
                    required
                    placeholder="7890"
                    value={verificationCode}
                    onChange={(e) => setVerificationCode(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-xl py-3 text-center text-lg tracking-[0.5em] font-mono text-white focus:outline-none focus:border-gold-500 transition"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-gold-600 to-gold-400 text-neutral-950 font-display font-bold py-2.5 rounded-xl text-xs transition duration-200 disabled:opacity-50 flex items-center justify-center gap-1"
                >
                  {isSubmitting && <Loader2 size={14} className="animate-spin" />}
                  Confirm & Initiate Account
                </button>

                <button
                  type="button"
                  onClick={() => setStep('form')}
                  className="w-full text-center text-xs text-neutral-400 hover:text-white transition mt-2"
                >
                  Return to Details
                </button>
              </form>
            )}

            {/* Step 3: Two-Factor Authentication (OTP) Simulation */}
            {step === 'twoFactor' && (
              <form onSubmit={handleVerify2FA} className="space-y-4">
                <div className="p-3 rounded-xl bg-gold-500/10 border border-gold-400/20 text-xs text-gold-300 flex items-center gap-2 mb-2">
                  <ShieldCheck size={16} className="shrink-0" />
                  <span>2FA Bypass Code: <strong className="font-mono text-white text-sm ml-1">123456</strong></span>
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-neutral-400 mb-1">Enter 6-Digit OTP</label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    placeholder="123456"
                    value={twoFactorCode}
                    onChange={(e) => setTwoFactorCode(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-xl py-3 text-center text-lg tracking-[0.5em] font-mono text-white focus:outline-none focus:border-gold-500 transition"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-gold-600 to-gold-400 text-neutral-950 font-display font-bold py-2.5 rounded-xl text-xs transition duration-200 disabled:opacity-50 flex items-center justify-center gap-1"
                >
                  {isSubmitting && <Loader2 size={14} className="animate-spin" />}
                  Verify & Log In
                </button>

                <button
                  type="button"
                  onClick={() => setStep('form')}
                  className="w-full text-center text-xs text-neutral-400 hover:text-white transition mt-2"
                >
                  Return to Details
                </button>
              </form>
            )}

            {/* Toggle Footer */}
            {step === 'form' && (
              <div className="mt-6 pt-5 border-t border-neutral-900 text-center text-xs text-neutral-400">
                {forgotPassword ? (
                  <button onClick={handleReset} className="text-gold-400 hover:underline">
                    Return to Log In
                  </button>
                ) : isLogin ? (
                  <>
                    Don't hold an account?{' '}
                    <button onClick={() => setIsLogin(false)} className="text-gold-400 hover:underline font-semibold">
                      Join Platform
                    </button>
                  </>
                ) : (
                  <>
                    Already subscribed?{' '}
                    <button onClick={() => setIsLogin(true)} className="text-gold-400 hover:underline font-semibold">
                      Log In Here
                    </button>
                  </>
                )}
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
