import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Users, Award, ExternalLink } from 'lucide-react';
import { Creator } from '../types';

interface CreatorCardProps {
  key?: React.Key;
  creator: Creator;
  onSelectCreator: (creatorId: string) => void;
  isFavorite: boolean;
  onToggleFavorite: (creatorId: string) => void;
}

export default function CreatorCard({ creator, onSelectCreator, isFavorite, onToggleFavorite }: CreatorCardProps) {
  return (
    <motion.div
      id={`creator-card-${creator.id}`}
      whileHover={{ y: -5 }}
      transition={{ duration: 0.2 }}
      className="group relative overflow-hidden rounded-2xl border border-neutral-900 bg-neutral-950 p-5 shadow-[0_4px_30px_rgba(0,0,0,0.5)] hover:border-gold-400/30 transition flex flex-col h-full text-white"
    >
      {/* Decorative Golden Background Glow */}
      <div className="absolute -top-12 -right-12 h-24 w-24 rounded-full bg-gold-500/5 blur-xl pointer-events-none group-hover:bg-gold-500/10 transition duration-300" />

      {/* Banner & Avatar Row */}
      <div className="relative h-28 rounded-xl overflow-hidden mb-4">
        <img
          src={creator.bannerUrl}
          alt={creator.name}
          className="w-full h-full object-cover transition duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/90 via-transparent to-transparent" />
        <div className="absolute top-2.5 right-2.5">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(creator.id);
            }}
            className="p-1.5 rounded-full bg-neutral-950/70 border border-neutral-850 backdrop-blur-sm text-gold-400 hover:scale-110 active:scale-95 transition"
          >
            {isFavorite ? '★' : '☆'}
          </button>
        </div>
      </div>

      {/* Profile Details */}
      <div className="flex items-start gap-3 -mt-10 relative z-10 px-1 mb-3">
        <img
          src={creator.avatarUrl}
          alt={creator.name}
          className="w-12 h-12 rounded-full border-2 border-gold-400 bg-neutral-950 object-cover"
        />
        <div className="mt-8">
          <h4 className="font-display font-bold text-sm tracking-tight text-white group-hover:text-gold-300 transition-colors">
            {creator.name}
          </h4>
          <span className="text-[10px] text-neutral-400 font-mono">@{creator.username}</span>
        </div>
      </div>

      {/* Category / Niche Badge */}
      <div className="mb-2">
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[9px] font-mono font-bold bg-gold-500/10 border border-gold-400/25 text-gold-400 uppercase">
          <Sparkles size={10} />
          {creator.category}
        </span>
      </div>

      {/* Bio Snippet */}
      <p className="text-xs text-neutral-300 leading-relaxed mb-4 line-clamp-2">
        {creator.bio}
      </p>

      {/* Tags Row */}
      <div className="flex flex-wrap gap-1 mb-5">
        {creator.tags.map((tag, i) => (
          <span key={i} className="text-[9px] bg-neutral-900 border border-neutral-850 text-neutral-400 px-1.5 py-0.5 rounded">
            #{tag}
          </span>
        ))}
      </div>

      {/* Footer statistics */}
      <div className="mt-auto pt-3 border-t border-neutral-900 flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-xs text-neutral-400">
          <Users size={14} className="text-gold-500" />
          <span className="font-semibold text-white">{creator.subscriberCount.toLocaleString()}</span>
          <span>supporters</span>
        </div>

        <button
          onClick={() => onSelectCreator(creator.id)}
          className="py-1 px-3 bg-neutral-900 border border-neutral-850 hover:bg-gradient-to-r hover:from-gold-600 hover:to-gold-400 hover:text-neutral-950 hover:border-transparent text-neutral-200 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all duration-300"
        >
          Explore Channel
          <ExternalLink size={12} />
        </button>
      </div>
    </motion.div>
  );
}
